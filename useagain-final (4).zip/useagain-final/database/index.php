<?php
// Silence is golden. This file intentionally left blank —
// it exists only to stop directory listing/direct browsing of this folder.
