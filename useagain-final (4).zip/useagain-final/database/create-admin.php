<?php
/**
 * UseAgain — First Admin Account Setup
 * ---------------------------------------
 * Run this ONCE, right after importing database/schema.sql, to create your
 * first admin login. It refuses to run again once any admin account
 * exists, so there's no risk of it being used to create a rogue account
 * later — but delete this file after use anyway, as a matter of hygiene.
 *
 * Why this exists instead of a seeded admin row in schema.sql: a hardcoded
 * default password (and its hash) would be identical across every copy of
 * this project, which is a real security risk if anyone forgets to change
 * it. This script hashes a password you choose, on the spot, with PHP's
 * own password_hash().
 *
 * HOW TO RUN ON GODADDY:
 *   Command line (cPanel → Terminal):   php database/create-admin.php
 *   Or visit in a browser once:          https://yourdomain.com/database/create-admin.php
 */

require_once __DIR__ . '/../includes/functions.php';

$pdo = getDbConnection();
$existingAdmins = (int) $pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();

if ($existingAdmins > 0) {
    $message = "An admin account already exists. This script only runs once, for safety.\nTo add more admins, do it from the Admin Panel → Manage Admins (once that module exists), or directly via phpMyAdmin.\nPlease delete this file (database/create-admin.php) if you haven't already.";
    if (php_sapi_name() === 'cli') {
        echo $message . "\n";
    } else {
        header('Content-Type: text/plain');
        echo $message;
    }
    exit;
}

$isCli = php_sapi_name() === 'cli';

if ($isCli) {
    // ---- Command-line flow ----
    echo "UseAgain — Create First Admin Account\n";
    echo "======================================\n";
    fwrite(STDOUT, "Admin name: ");
    $name = trim(fgets(STDIN));
    fwrite(STDOUT, "Admin email: ");
    $email = trim(fgets(STDIN));
    fwrite(STDOUT, "Admin password (min 8 characters): ");
    $password = trim(fgets(STDIN));

    if (mb_strlen($name) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
        echo "\nInvalid input — name, a valid email, and a password of at least 8 characters are required.\n";
        exit(1);
    }

    $stmt = $pdo->prepare('INSERT INTO admins (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
    $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), 'super_admin']);

    echo "\nAdmin account created for $email.\n";
    echo "Now DELETE this file (database/create-admin.php) and log in at /admin/login.php.\n";
    exit(0);
}

// ---- Browser flow ----
$errors = [];
$done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired — please try again.';
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $passwordConfirm = $_POST['password_confirm'] ?? '';

        if (mb_strlen($name) < 2) $errors[] = 'Please enter a name.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email.';
        if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
        if ($password !== $passwordConfirm) $errors[] = 'Passwords do not match.';

        if (empty($errors)) {
            $stmt = $pdo->prepare('INSERT INTO admins (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), 'super_admin']);
            $done = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create First Admin - UseAgain</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<section style="padding-top:60px; padding-bottom:80px;">
  <div class="container" style="max-width:460px;">
    <h1 class="section-title">Create First Admin Account</h1>

    <?php if ($done): ?>
      <div class="alert alert-success">
        ✅ Admin account created. <strong>Now delete this file</strong> (<code>database/create-admin.php</code>) from your server, then log in at <a href="<?= BASE_URL ?>/admin/login.php">/admin/login.php</a>.
      </div>
    <?php else: ?>
      <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
          <ul style="margin:0 0 0 20px;"><?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>
      <form class="form-card" method="post">
        <?= csrf_field() ?>
        <div class="form-group"><label for="name">Name</label><input type="text" id="name" name="name" required autofocus></div>
        <div class="form-group"><label for="email">Email</label><input type="email" id="email" name="email" required></div>
        <div class="form-group"><label for="password">Password</label><input type="password" id="password" name="password" required minlength="8"></div>
        <div class="form-group"><label for="password_confirm">Confirm Password</label><input type="password" id="password_confirm" name="password_confirm" required minlength="8"></div>
        <button type="submit" class="btn btn-primary btn-block">Create Admin Account</button>
      </form>
    <?php endif; ?>
  </div>
</section>
</body>
</html>
