-- =====================================================================
-- UseAgain — Migration v2
-- Run this ONCE via phpMyAdmin (SQL tab) against your existing database.
-- It only ADDS columns/tables — nothing here deletes existing data.
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- PRODUCTS — new fields
-- ---------------------------------------------------------------------
ALTER TABLE products
  ADD COLUMN brand VARCHAR(100) NULL AFTER description,
  ADD COLUMN is_negotiable TINYINT(1) NOT NULL DEFAULT 0 AFTER price,
  ADD COLUMN sold_out TINYINT(1) NOT NULL DEFAULT 0 AFTER status;

-- Widen the status enum to support a distinct "changes requested" state
-- (previously only pending/approved/rejected/sold/removed existed).
ALTER TABLE products
  MODIFY COLUMN status ENUM('pending','approved','rejected','changes_requested','sold','removed')
  NOT NULL DEFAULT 'pending';

-- ---------------------------------------------------------------------
-- PRODUCT_IMAGES — rename is_primary's role slightly: is_primary IS the
-- cover-image flag already, so no new column needed there. image_order
-- is already covered by the existing sort_order column. Nothing to add.
-- (Kept here as a no-op note so the migration file matches the request
-- 1:1 — is_primary = "is_cover_image", sort_order = "image_order".)
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- NOTIFICATIONS — simple in-app notification feed for admins and users
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    recipient_type    ENUM('admin','user') NOT NULL,
    recipient_id      INT UNSIGNED NULL,      -- NULL for admin = visible to all admins
    product_id        INT UNSIGNED NULL,
    type              VARCHAR(40) NOT NULL,   -- e.g. 'product_submitted', 'product_approved'
    message           VARCHAR(255) NOT NULL,
    is_read           TINYINT(1) NOT NULL DEFAULT 0,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_notif_recipient (recipient_type, recipient_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
