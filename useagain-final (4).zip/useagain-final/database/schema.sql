-- =====================================================================
-- UseAgain — MySQL Database Schema (Module 2)
-- Engine: InnoDB | Charset: utf8mb4 (full Unicode + emoji support)
-- Compatible with MySQL 5.7+ / MariaDB 10.3+ (GoDaddy shared hosting)
-- =====================================================================
-- HOW TO IMPORT ON GODADDY:
--   1. cPanel → MySQL Databases → create a database + user, add the user
--      to the database with ALL PRIVILEGES. GoDaddy prefixes both names,
--      e.g. "yourcpaneluser_useagain".
--   2. cPanel → phpMyAdmin → select the new database → Import → choose
--      this file → Go.
--   3. Update your DB config (added in a later module) with the exact
--      database name, username, and password GoDaddy gave you.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- 1. USERS — registered buyers/sellers/donors (public-facing accounts).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name              VARCHAR(150) NOT NULL,
    email             VARCHAR(190) NOT NULL UNIQUE,
    phone             VARCHAR(20)  NOT NULL,
    whatsapp_number   VARCHAR(20)  NOT NULL,
    password_hash     VARCHAR(255) NOT NULL,
    status            ENUM('active','suspended') NOT NULL DEFAULT 'active',
    last_login_at     TIMESTAMP NULL,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_users_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 2. ADMINS — separate, privileged login for the admin panel.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name              VARCHAR(150) NOT NULL,
    email             VARCHAR(190) NOT NULL UNIQUE,
    password_hash     VARCHAR(255) NOT NULL,
    role              ENUM('super_admin','admin') NOT NULL DEFAULT 'admin',
    is_active         TINYINT(1) NOT NULL DEFAULT 1,
    last_login_at     TIMESTAMP NULL,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 3. CATEGORIES — the 8 fixed main categories.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name              VARCHAR(150) NOT NULL,
    slug              VARCHAR(150) NOT NULL UNIQUE,
    icon              VARCHAR(20)  DEFAULT '📦',
    sort_order        INT NOT NULL DEFAULT 0,
    status            ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_categories_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 4. SUBCATEGORIES — belong to exactly one main category.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS subcategories (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id       INT UNSIGNED NOT NULL,
    name              VARCHAR(150) NOT NULL,
    slug              VARCHAR(150) NOT NULL,
    sort_order        INT NOT NULL DEFAULT 0,
    status            ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_category_slug (category_id, slug),
    INDEX idx_subcategories_category (category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 5. PRODUCTS — the core listing table. Visible on the site only once
--    status = 'approved' (enforced in application logic).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id           INT UNSIGNED NOT NULL,
    category_id       INT UNSIGNED NOT NULL,
    subcategory_id    INT UNSIGNED NOT NULL,

    title             VARCHAR(200) NOT NULL,
    slug              VARCHAR(220) NOT NULL UNIQUE,        -- SEO-friendly URL segment
    description       TEXT NOT NULL,
    brand             VARCHAR(100) NULL,
    condition_type    ENUM('New','Like New','Good','Fair') NOT NULL,
    listing_type      ENUM('sell','donate') NOT NULL DEFAULT 'sell',
    price             DECIMAL(10,2) NULL,                  -- NULL for donations
    is_negotiable     TINYINT(1) NOT NULL DEFAULT 0,

    address           VARCHAR(255) NOT NULL,
    area              VARCHAR(150) NOT NULL,
    city              VARCHAR(100) NOT NULL,
    state             VARCHAR(100) NOT NULL,
    pincode           VARCHAR(10)  NOT NULL,

    contact_number    VARCHAR(20)  NOT NULL,
    whatsapp_number   VARCHAR(20)  NOT NULL,

    status            ENUM('pending','approved','rejected','changes_requested','sold','removed') NOT NULL DEFAULT 'pending',
    sold_out          TINYINT(1) NOT NULL DEFAULT 0,
    rejection_reason  TEXT NULL,
    is_featured       TINYINT(1) NOT NULL DEFAULT 0,
    views             INT UNSIGNED NOT NULL DEFAULT 0,

    approved_by       INT UNSIGNED NULL,                   -- admins.id
    approved_at       TIMESTAMP NULL,

    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
    FOREIGN KEY (subcategory_id) REFERENCES subcategories(id) ON DELETE RESTRICT,
    FOREIGN KEY (approved_by) REFERENCES admins(id) ON DELETE SET NULL,

    INDEX idx_products_status (status),
    INDEX idx_products_category (category_id),
    INDEX idx_products_subcategory (subcategory_id),
    INDEX idx_products_user (user_id),
    INDEX idx_products_listing_type (listing_type),
    INDEX idx_products_city (city),
    INDEX idx_products_created (created_at),
    FULLTEXT INDEX ft_products_search (title, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 6. PRODUCT_IMAGES — one row per uploaded photo. Only the filename is
--    stored; files live on disk at uploads/products/YYYY/MM/.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS product_images (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_id        INT UNSIGNED NOT NULL,
    filename          VARCHAR(255) NOT NULL,               -- e.g. 64f1c2a9b3d21.jpg
    upload_year       CHAR(4)  NOT NULL,                   -- e.g. '2026' (mirrors the YYYY/MM folder)
    upload_month      CHAR(2)  NOT NULL,                   -- e.g. '07'
    is_primary        TINYINT(1) NOT NULL DEFAULT 0,
    sort_order        INT NOT NULL DEFAULT 0,
    uploaded_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_product_images_product (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 7. TESTIMONIALS — homepage customer quotes (admin-managed, part of
--    "Manage Homepage").
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS testimonials (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name              VARCHAR(150) NOT NULL,
    location          VARCHAR(150) NOT NULL,               -- e.g. area/city
    message           TEXT NOT NULL,
    rating            TINYINT UNSIGNED NOT NULL DEFAULT 5,  -- 1-5
    is_active         TINYINT(1) NOT NULL DEFAULT 1,
    sort_order        INT NOT NULL DEFAULT 0,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 8. CONTACT_MESSAGES — submissions from the site's Contact form.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contact_messages (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name              VARCHAR(150) NOT NULL,
    email             VARCHAR(190) NOT NULL,
    phone             VARCHAR(20),
    subject           VARCHAR(200),
    message           TEXT NOT NULL,
    is_read           TINYINT(1) NOT NULL DEFAULT 0,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 9. SETTINGS — key/value store for homepage & site-wide content the
--    admin can edit (WhatsApp number, contact email, banner text, etc.)
--    without touching code.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
    setting_key       VARCHAR(100) PRIMARY KEY,
    setting_value     TEXT,
    updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- 10. NOTIFICATIONS — simple in-app feed for admins and users
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    recipient_type    ENUM('admin','user') NOT NULL,
    recipient_id      INT UNSIGNED NULL,      -- NULL for admin = visible to all admins
    product_id        INT UNSIGNED NULL,
    type              VARCHAR(40) NOT NULL,
    message           VARCHAR(255) NOT NULL,
    is_read           TINYINT(1) NOT NULL DEFAULT 0,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_notif_recipient (recipient_type, recipient_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- SEED DATA — the 8 main categories and all fixed subcategories
-- =====================================================================

INSERT INTO categories (name, slug, icon, sort_order) VALUES
('Baby & Kids',            'baby-kids',              '🧸', 1),
('Books & Education',      'books-education',        '📚', 2),
('Home Essentials',        'home-essentials',        '🏠', 3),
('Vehicles',                'vehicles',               '🚗', 4),
('Construction Materials', 'construction-materials', '🏗', 5),
('Electronics',             'electronics',            '📱', 6),
('Fashion',                  'fashion',                '👕', 7),
('Miscellaneous',            'miscellaneous',          '📦', 8);

-- Baby & Kids
INSERT INTO subcategories (category_id, name, slug, sort_order)
SELECT id, sub.name, sub.slug, sub.ord FROM categories,
(SELECT 'Toys' AS name, 'toys' AS slug, 1 AS ord
 UNION ALL SELECT 'Baby Products', 'baby-products', 2
 UNION ALL SELECT 'Baby Furniture', 'baby-furniture', 3
 UNION ALL SELECT 'Baby Clothing', 'baby-clothing', 4) AS sub
WHERE categories.slug = 'baby-kids';

-- Books & Education
INSERT INTO subcategories (category_id, name, slug, sort_order)
SELECT id, sub.name, sub.slug, sub.ord FROM categories,
(SELECT 'School Books' AS name, 'school-books' AS slug, 1 AS ord
 UNION ALL SELECT 'College Books', 'college-books', 2
 UNION ALL SELECT 'Story Books', 'story-books', 3
 UNION ALL SELECT 'Stationery', 'stationery', 4) AS sub
WHERE categories.slug = 'books-education';

-- Home Essentials
INSERT INTO subcategories (category_id, name, slug, sort_order)
SELECT id, sub.name, sub.slug, sub.ord FROM categories,
(SELECT 'Furniture' AS name, 'furniture' AS slug, 1 AS ord
 UNION ALL SELECT 'Kitchen Items', 'kitchen-items', 2
 UNION ALL SELECT 'Pressure Cooker', 'pressure-cooker', 3
 UNION ALL SELECT 'Mixer Grinder', 'mixer-grinder', 4
 UNION ALL SELECT 'Water Purifier', 'water-purifier', 5
 UNION ALL SELECT 'Geyser', 'geyser', 6
 UNION ALL SELECT 'Air Cooler', 'air-cooler', 7
 UNION ALL SELECT 'Washing Machine', 'washing-machine', 8
 UNION ALL SELECT 'Refrigerator', 'refrigerator', 9
 UNION ALL SELECT 'Home Decor', 'home-decor', 10) AS sub
WHERE categories.slug = 'home-essentials';

-- Vehicles
INSERT INTO subcategories (category_id, name, slug, sort_order)
SELECT id, sub.name, sub.slug, sub.ord FROM categories,
(SELECT 'Bicycle' AS name, 'bicycle' AS slug, 1 AS ord
 UNION ALL SELECT 'Bike', 'bike', 2
 UNION ALL SELECT 'Scooter', 'scooter', 3
 UNION ALL SELECT 'Car', 'car', 4
 UNION ALL SELECT 'Tractor', 'tractor', 5
 UNION ALL SELECT 'Vehicle Spare Parts', 'vehicle-spare-parts', 6) AS sub
WHERE categories.slug = 'vehicles';

-- Construction Materials
INSERT INTO subcategories (category_id, name, slug, sort_order)
SELECT id, sub.name, sub.slug, sub.ord FROM categories,
(SELECT 'Cement' AS name, 'cement' AS slug, 1 AS ord
 UNION ALL SELECT 'Steel', 'steel', 2
 UNION ALL SELECT 'Bricks', 'bricks', 3
 UNION ALL SELECT 'Plumbing', 'plumbing', 4
 UNION ALL SELECT 'Electrical', 'electrical', 5
 UNION ALL SELECT 'Paint', 'paint', 6
 UNION ALL SELECT 'Tiles', 'tiles', 7) AS sub
WHERE categories.slug = 'construction-materials';

-- Electronics
INSERT INTO subcategories (category_id, name, slug, sort_order)
SELECT id, sub.name, sub.slug, sub.ord FROM categories,
(SELECT 'Mobile' AS name, 'mobile' AS slug, 1 AS ord
 UNION ALL SELECT 'Laptop', 'laptop', 2
 UNION ALL SELECT 'TV', 'tv', 3
 UNION ALL SELECT 'Printer', 'printer', 4
 UNION ALL SELECT 'Camera', 'camera', 5) AS sub
WHERE categories.slug = 'electronics';

-- Fashion
INSERT INTO subcategories (category_id, name, slug, sort_order)
SELECT id, sub.name, sub.slug, sub.ord FROM categories,
(SELECT 'Clothing' AS name, 'clothing' AS slug, 1 AS ord
 UNION ALL SELECT 'Footwear', 'footwear', 2
 UNION ALL SELECT 'Bags', 'bags', 3
 UNION ALL SELECT 'Watches', 'watches', 4) AS sub
WHERE categories.slug = 'fashion';

-- Miscellaneous
INSERT INTO subcategories (category_id, name, slug, sort_order)
SELECT id, sub.name, sub.slug, sub.ord FROM categories,
(SELECT 'Sports' AS name, 'sports' AS slug, 1 AS ord
 UNION ALL SELECT 'Gardening', 'gardening', 2
 UNION ALL SELECT 'Musical Instruments', 'musical-instruments', 3
 UNION ALL SELECT 'Pet Accessories', 'pet-accessories', 4
 UNION ALL SELECT 'Others', 'others', 5) AS sub
WHERE categories.slug = 'miscellaneous';

-- ---------------------------------------------------------------------
-- Default site settings (edit values later from the admin panel)
-- ---------------------------------------------------------------------
INSERT INTO settings (setting_key, setting_value) VALUES
('site_name',        'UseAgain'),
('site_tagline',     'Buy, Sell and Donate Reusable Products'),
('whatsapp_number',  '919492060241'),
('contact_email',    'srikanth.v@useagain.in'),
('homepage_banner_title',    'Give it a second life, not a place in the landfill.'),
('homepage_banner_subtitle', 'Buy, sell and donate reusable products in your community.');
