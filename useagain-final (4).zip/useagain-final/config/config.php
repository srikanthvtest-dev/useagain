<?php
/**
 * UseAgain — Global Configuration
 * Loaded first by every page (directly or via includes/functions.php).
 */

// Start the session before ANY output anywhere — this must happen here,
// at the very top of the very first file every page loads, or session
// cookies (used for login, CSRF tokens, etc.) silently fail to persist.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- ENVIRONMENT ----
// Set to false once the site is live on GoDaddy and working correctly.
define('APP_DEBUG', true);

if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

date_default_timezone_set('Asia/Kolkata');

// ---- SITE IDENTITY ----
define('SITE_NAME', 'UseAgain');
define('SITE_TAGLINE', 'Buy, Sell and Donate Reusable Products');
define('CONTACT_EMAIL', 'srikanth.v@useagain.in');
define('WHATSAPP_NUMBER', '919492060241'); // country code + number, no + or spaces
define('CONTACT_PHONE_DISPLAY', '+91 94920 60241');

// ---- PATHS / URLS ----
// BASE_URL is computed from config.php's OWN fixed location relative to the
// web root — not from whichever script is currently running — so it
// resolves correctly no matter how deeply nested a page is (e.g. /admin/).
$documentRoot = rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
$configDir    = rtrim(str_replace('\\', '/', dirname(__DIR__)), '/');
if ($documentRoot && str_starts_with($configDir, $documentRoot)) {
    $basePath = substr($configDir, strlen($documentRoot));
} else {
    $basePath = ''; // fallback: assume the site is deployed at the web root
}
define('BASE_URL', $basePath === '/' ? '' : $basePath);

define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/products/');   // filesystem path
define('UPLOAD_URL', BASE_URL . '/uploads/products/');            // browser-facing path

// ---- UPLOAD LIMITS (used by the product posting module) ----
define('MAX_IMAGES_PER_PRODUCT', 3);
define('MAX_IMAGE_DIMENSION', 1400);
define('IMAGE_JPEG_QUALITY', 82);

// Bump this any time style.css / script.js / admin.css / admin.js change,
// so browsers fetch the new version instead of serving a stale cached copy.
define('ASSET_VERSION', '3');

// ---- PAGINATION ----
define('PRODUCTS_PER_PAGE', 12);

// ---- SECURITY ----
define('HONEYPOT_FIELD', 'website_url');
define('FORM_RATE_LIMIT_SECONDS', 15);

// ---- DATABASE CONNECTION ----
require_once __DIR__ . '/database.php';
