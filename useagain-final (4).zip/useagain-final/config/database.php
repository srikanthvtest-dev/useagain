<?php
/**
 * UseAgain — Database Connection (PDO)
 * -------------------------------------
 * Fill in the four constants below with the values GoDaddy's cPanel gives
 * you after creating a MySQL database (cPanel → MySQL Databases):
 *   - Database name is usually prefixed, e.g. "yourcpaneluser_useagain"
 *   - Username is usually prefixed too, e.g. "yourcpaneluser_useagainuser"
 *   - Host is almost always "localhost" on GoDaddy shared hosting
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'useagain_db');
define('DB_USER', 'useagain_user');
define('DB_PASS', 'CHANGE_ME');
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a shared PDO connection. Call this anywhere with:
 *   $pdo = getDbConnection();
 *   $stmt = $pdo->prepare('SELECT * FROM categories WHERE status = ?');
 *   $stmt->execute(['active']);
 *   $categories = $stmt->fetchAll();
 */
function getDbConnection(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements, not emulated
        ]);
    } catch (PDOException $e) {
        // Never leak DB credentials or raw exception details to visitors.
        error_log('UseAgain DB connection failed: ' . $e->getMessage());
        http_response_code(500);
        if (defined('APP_DEBUG') && APP_DEBUG) {
            die('Database connection failed: ' . htmlspecialchars($e->getMessage()) . '<br>Check config/database.php.');
        }
        die('We are unable to connect right now. Please try again shortly.');
    }

    return $pdo;
}
