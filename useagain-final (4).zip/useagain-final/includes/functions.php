<?php
require_once __DIR__ . '/../config/config.php';

/* =====================================================================
   SETTINGS
   ===================================================================== */

function getSetting($key, $default = '') {
    static $cache = null;
    if ($cache === null) {
        $pdo = getDbConnection();
        $cache = [];
        foreach ($pdo->query('SELECT setting_key, setting_value FROM settings') as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return $cache[$key] ?? $default;
}

/* =====================================================================
   CATEGORIES
   ===================================================================== */

/** All active main categories, in display order. */
function getCategories() {
    static $cache = null;
    if ($cache !== null) return $cache;
    $pdo = getDbConnection();
    $stmt = $pdo->query("SELECT * FROM categories WHERE status = 'active' ORDER BY sort_order, name");
    $cache = $stmt->fetchAll();
    return $cache;
}

function getCategoryById($id) {
    foreach (getCategories() as $c) {
        if ((int) $c['id'] === (int) $id) return $c;
    }
    return null;
}

function getCategoryBySlug($slug) {
    foreach (getCategories() as $c) {
        if ($c['slug'] === $slug) return $c;
    }
    return null;
}

/** Active subcategories belonging to one category. */
function getSubcategories($categoryId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare("SELECT * FROM subcategories WHERE category_id = ? AND status = 'active' ORDER BY sort_order, name");
    $stmt->execute([$categoryId]);
    return $stmt->fetchAll();
}

/** How many approved products currently sit in a category (shown on the homepage category cards). */
function countProductsInCategory($categoryId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ? AND status = 'approved'");
    $stmt->execute([$categoryId]);
    return (int) $stmt->fetchColumn();
}

/* =====================================================================
   PRODUCTS
   ===================================================================== */

const PRODUCT_LIST_SELECT = "
    SELECT p.*, c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon,
           s.name AS subcategory_name, s.slug AS subcategory_slug
    FROM products p
    JOIN categories c ON c.id = p.category_id
    JOIN subcategories s ON s.id = p.subcategory_id
";

/** Attaches the ordered image list to a single product row (or array of rows). */
function attachProductImages($products) {
    $pdo = getDbConnection();
    $single = isset($products['id']);
    $rows = $single ? [$products] : $products;
    if (empty($rows)) return $products;

    $ids = array_column($rows, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM product_images WHERE product_id IN ($placeholders) ORDER BY is_primary DESC, sort_order ASC");
    $stmt->execute($ids);
    $imagesByProduct = [];
    foreach ($stmt->fetchAll() as $img) {
        $imagesByProduct[$img['product_id']][] = productImageUrl($img);
    }

    foreach ($rows as &$row) {
        $row['images'] = $imagesByProduct[$row['id']] ?? [];
    }
    unset($row);

    return $single ? $rows[0] : $rows;
}

function productImageUrl($imageRow) {
    return UPLOAD_URL . $imageRow['upload_year'] . '/' . $imageRow['upload_month'] . '/' . $imageRow['filename'];
}

/** Newest approved products first, one per category where possible — used for "Featured Products". */
function getFeaturedProducts($limit = 8) {
    $pdo = getDbConnection();
    $stmt = $pdo->query(PRODUCT_LIST_SELECT . " WHERE p.status = 'approved' ORDER BY p.is_featured DESC, p.created_at DESC LIMIT " . (int) $limit);
    return attachProductImages($stmt->fetchAll());
}

/** Most recently approved products — "Latest Products". */
function getLatestProducts($limit = 8) {
    $pdo = getDbConnection();
    $stmt = $pdo->query(PRODUCT_LIST_SELECT . " WHERE p.status = 'approved' ORDER BY p.created_at DESC LIMIT " . (int) $limit);
    return attachProductImages($stmt->fetchAll());
}

function getProductById($id) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(PRODUCT_LIST_SELECT . " WHERE p.id = ? LIMIT 1");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    return $product ? attachProductImages($product) : null;
}

function getProductBySlug($slug) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(PRODUCT_LIST_SELECT . " WHERE p.slug = ? LIMIT 1");
    $stmt->execute([$slug]);
    $product = $stmt->fetch();
    return $product ? attachProductImages($product) : null;
}

function countApprovedProducts() {
    $pdo = getDbConnection();
    return (int) $pdo->query("SELECT COUNT(*) FROM products WHERE status = 'approved'")->fetchColumn();
}

/* =====================================================================
   TESTIMONIALS
   ===================================================================== */

function getTestimonials($limit = 6) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare("SELECT * FROM testimonials WHERE is_active = 1 ORDER BY sort_order, created_at DESC LIMIT ?");
    $stmt->bindValue(1, (int) $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/* =====================================================================
   FORMATTING HELPERS
   ===================================================================== */

function formatPrice($price) {
    if ($price === null || $price === '') return null;
    return '₹' . number_format((float) $price, 0);
}

function timeAgo($datetime) {
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . ' min ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hr ago';
    if ($diff < 2592000) return floor($diff / 86400) . ' days ago';
    return date('d M Y', strtotime($datetime));
}

/** Builds a WhatsApp enquiry link for a given product row. */
function whatsappLink($product) {
    $number = preg_replace('/\D/', '', $product['whatsapp_number'] ?? WHATSAPP_NUMBER);
    $msg = "Hi, I'm interested in \"" . ($product['title'] ?? 'this item') . "\" listed on UseAgain.";
    return 'https://wa.me/' . $number . '?text=' . rawurlencode($msg);
}

function slugify($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = trim($text, '-');
    $text = strtolower($text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    return $text ?: 'item';
}

/* =====================================================================
   SECURITY HELPERS — CSRF tokens, honeypot spam check, rate limiting
   (used by every form module going forward)
   ===================================================================== */

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

function csrf_verify($token) {
    return !empty($_SESSION['csrf_token']) && !empty($token) && hash_equals($_SESSION['csrf_token'], $token);
}

function isHoneypotTriggered($post) {
    return !empty($post[HONEYPOT_FIELD] ?? '');
}

function isRateLimited($formKey) {
    $sessionKey = 'last_submit_' . $formKey;
    $now = time();
    if (!empty($_SESSION[$sessionKey]) && ($now - $_SESSION[$sessionKey]) < FORM_RATE_LIMIT_SECONDS) {
        return true;
    }
    $_SESSION[$sessionKey] = $now;
    return false;
}

/* =====================================================================
   AUTH HELPERS
   ===================================================================== */

function isUserLoggedIn() {
    return !empty($_SESSION['user_id']);
}

function currentUser() {
    if (!isUserLoggedIn()) return null;
    static $cache = null;
    if ($cache !== null) return $cache;
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT id, name, email, phone, whatsapp_number, status, created_at FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $cache = $stmt->fetch() ?: null;
    return $cache;
}

/** Looks up a user by email — used at both registration (uniqueness check) and login. */
function findUserByEmail($email) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    return $stmt->fetch() ?: null;
}

/** Creates a new user account. Expects an already-hashed password. Returns the new user's id. */
function createUser($name, $email, $phone, $whatsapp, $passwordHash) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(
        'INSERT INTO users (name, email, phone, whatsapp_number, password_hash) VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->execute([$name, $email, $phone, $whatsapp, $passwordHash]);
    return (int) $pdo->lastInsertId();
}

/** Records a successful login timestamp. */
function touchLastLogin($userId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?');
    $stmt->execute([$userId]);
}

/** Logs a user in: regenerates the session ID (prevents session fixation) and stores the user id. */
function logUserIn($userId) {
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
}

function logUserOut() {
    unset($_SESSION['user_id']);
    session_regenerate_id(true);
}

/** All listings (any status) posted by one user — for their "My Account" page. */
function getProductsByUser($userId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(PRODUCT_LIST_SELECT . ' WHERE p.user_id = ? ORDER BY p.created_at DESC');
    $stmt->execute([$userId]);
    return attachProductImages($stmt->fetchAll());
}

/**
 * Only allows redirecting back to a relative path within this site —
 * blocks "?redirect=https://evil.example.com" style open-redirect abuse.
 */
function safeRedirectPath($path, $default = '/my-account.php') {
    if (!$path || !is_string($path)) return $default;
    if (str_starts_with($path, '//') || preg_match('~^[a-z]+://~i', $path)) return $default;
    if (!str_starts_with($path, '/')) $path = '/' . $path;
    return $path;
}

/* =====================================================================
   ADMIN AUTH — completely separate from the regular user session
   ('admin_id' vs 'user_id'), its own table, its own login page.
   ===================================================================== */

function isAdminLoggedIn() {
    return !empty($_SESSION['admin_id']);
}

function currentAdmin() {
    if (!isAdminLoggedIn()) return null;
    static $cache = null;
    if ($cache !== null) return $cache;
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT id, name, email, role, last_login_at FROM admins WHERE id = ? AND is_active = 1');
    $stmt->execute([$_SESSION['admin_id']]);
    $cache = $stmt->fetch() ?: null;
    return $cache;
}

/** Put this at the very top of every admin/*.php page that isn't the login page itself. */
function requireAdminLogin() {
    if (!isAdminLoggedIn() || !currentAdmin()) {
        header('Location: ' . BASE_URL . '/admin/login.php');
        exit;
    }
}

function findAdminByEmail($email) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM admins WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    return $stmt->fetch() ?: null;
}

function logAdminIn($adminId) {
    session_regenerate_id(true);
    $_SESSION['admin_id'] = $adminId;
}

function logAdminOut() {
    unset($_SESSION['admin_id']);
    session_regenerate_id(true);
}

function touchAdminLastLogin($adminId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('UPDATE admins SET last_login_at = NOW() WHERE id = ?');
    $stmt->execute([$adminId]);
}

/** Looks up one subcategory by id, only if it belongs to the given category (defense against tampering). */
function getSubcategoryForCategory($subcategoryId, $categoryId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM subcategories WHERE id = ? AND category_id = ? AND status = "active" LIMIT 1');
    $stmt->execute([$subcategoryId, $categoryId]);
    return $stmt->fetch() ?: null;
}

/** Generates a URL slug guaranteed not to collide with an existing product. */
function uniqueProductSlug($title) {
    $pdo = getDbConnection();
    $base = slugify($title);
    $slug = $base;
    $i = 1;
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM products WHERE slug = ?');
    while (true) {
        $stmt->execute([$slug]);
        if ((int) $stmt->fetchColumn() === 0) {
            return $slug;
        }
        $i++;
        $slug = $base . '-' . $i;
    }
}

/**
 * Inserts a new product row (status always starts as 'pending') and
 * returns its new id.
 */
/**
 * NOTE: Per current site policy, listings go live immediately — no admin
 * approval step. New listings are inserted directly as "approved" with
 * approved_at set to now (approved_by stays NULL since no admin reviewed
 * it). Admins can still reject/remove a listing after the fact from
 * admin/products.php if it turns out to violate the rules.
 */
/**
 * Per current site policy, listings require admin approval before they
 * appear publicly — every new listing starts as "pending" and admins
 * are notified so they can review it from admin/products.php.
 */
function createProduct(array $data) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(
        'INSERT INTO products
         (user_id, category_id, subcategory_id, title, slug, description, brand, condition_type, listing_type, price, is_negotiable,
          address, area, city, state, pincode, contact_number, whatsapp_number, status)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,"pending")'
    );
    $stmt->execute([
        $data['user_id'], $data['category_id'], $data['subcategory_id'], $data['title'], $data['slug'],
        $data['description'], $data['brand'] ?: null, $data['condition_type'], $data['listing_type'], $data['price'], $data['is_negotiable'] ? 1 : 0,
        $data['address'], $data['area'], $data['city'], $data['state'], $data['pincode'],
        $data['contact_number'], $data['whatsapp_number'],
    ]);
    $productId = (int) $pdo->lastInsertId();

    createNotification('admin', null, $productId, 'product_submitted', 'New listing "' . $data['title'] . '" was submitted and needs review.');

    return $productId;
}

/** Full field update for an existing product — used by both the owner's edit page and the admin edit page. */
function updateProductFields($productId, array $data) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(
        'UPDATE products SET
           category_id = ?, subcategory_id = ?, title = ?, description = ?, brand = ?, condition_type = ?,
           listing_type = ?, price = ?, is_negotiable = ?, address = ?, area = ?, city = ?, state = ?, pincode = ?,
           contact_number = ?, whatsapp_number = ?
         WHERE id = ?'
    );
    $stmt->execute([
        $data['category_id'], $data['subcategory_id'], $data['title'], $data['description'], $data['brand'] ?: null,
        $data['condition_type'], $data['listing_type'], $data['price'], $data['is_negotiable'] ? 1 : 0,
        $data['address'], $data['area'], $data['city'], $data['state'], $data['pincode'],
        $data['contact_number'], $data['whatsapp_number'], $productId,
    ]);
}

/** Saves the uploaded image records (from handleProductImageUploads()) against a product. */
function insertProductImages($productId, array $images) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(
        'INSERT INTO product_images (product_id, filename, upload_year, upload_month, is_primary, sort_order) VALUES (?,?,?,?,?,?)'
    );
    foreach ($images as $index => $img) {
        $stmt->execute([$productId, $img['filename'], $img['upload_year'], $img['upload_month'], $index === 0 ? 1 : 0, $index]);
    }
}

/** A product owned by this user (used so a seller can't edit/view someone else's listing by guessing an id). */
function getProductByIdForUser($id, $userId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(PRODUCT_LIST_SELECT . ' WHERE p.id = ? AND p.user_id = ? LIMIT 1');
    $stmt->execute([$id, $userId]);
    $product = $stmt->fetch();
    return $product ? attachProductImages($product) : null;
}

/**
 * Builds the filtered, paginated public "browse products" query used by
 * products.php. $filters keys (all optional): q, category (slug),
 * subcategory (slug), listing_type, condition_type, min_price, max_price,
 * city, sort ('newest'|'price_low'|'price_high'|'most_viewed').
 */
function getProductsForBrowse(array $filters, $page, $perPage) {
    $pdo = getDbConnection();
    $where = ['p.status = "approved"'];
    $params = [];

    $q = trim($filters['q'] ?? '');
    if ($q !== '') {
        $where[] = '(MATCH(p.title, p.description) AGAINST (? IN NATURAL LANGUAGE MODE) OR p.title LIKE ?)';
        $params[] = $q;
        $params[] = '%' . $q . '%';
    }
    if (!empty($filters['category'])) {
        $where[] = 'c.slug = ?';
        $params[] = $filters['category'];
    }
    if (!empty($filters['subcategory'])) {
        $where[] = 's.slug = ?';
        $params[] = $filters['subcategory'];
    }
    if (!empty($filters['listing_type']) && in_array($filters['listing_type'], ['sell', 'donate'], true)) {
        $where[] = 'p.listing_type = ?';
        $params[] = $filters['listing_type'];
    }
    if (!empty($filters['condition_type']) && in_array($filters['condition_type'], ['New', 'Like New', 'Good', 'Fair'], true)) {
        $where[] = 'p.condition_type = ?';
        $params[] = $filters['condition_type'];
    }
    if (($filters['min_price'] ?? '') !== '') {
        $where[] = 'p.price >= ?';
        $params[] = (float) $filters['min_price'];
    }
    if (($filters['max_price'] ?? '') !== '') {
        $where[] = 'p.price <= ?';
        $params[] = (float) $filters['max_price'];
    }
    if (!empty($filters['city'])) {
        $where[] = 'p.city LIKE ?';
        $params[] = '%' . $filters['city'] . '%';
    }

    $orderBy = match ($filters['sort'] ?? 'newest') {
        'price_low'   => 'p.price ASC',
        'price_high'  => 'p.price DESC',
        'most_viewed' => 'p.views DESC',
        default       => 'p.created_at DESC',
    };

    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM products p JOIN categories c ON c.id = p.category_id JOIN subcategories s ON s.id = p.subcategory_id $whereSql");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $offset = max(0, ($page - 1) * $perPage);
    $stmt = $pdo->prepare(PRODUCT_LIST_SELECT . " $whereSql ORDER BY $orderBy LIMIT $perPage OFFSET $offset");
    $stmt->execute($params);
    $products = attachProductImages($stmt->fetchAll());

    return ['products' => $products, 'total' => $total];
}

/** Increments the view counter for a product (called once per details-page load). */
function incrementProductViews($productId) {
    $pdo = getDbConnection();
    $pdo->prepare('UPDATE products SET views = views + 1 WHERE id = ?')->execute([$productId]);
}

/** Up to 4 other approved products in the same category — shown on the details page. */
function getRelatedProducts($categoryId, $excludeProductId, $limit = 4) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(PRODUCT_LIST_SELECT . ' WHERE p.category_id = ? AND p.id != ? AND p.status = "approved" ORDER BY p.created_at DESC LIMIT ' . (int) $limit);
    $stmt->execute([$categoryId, $excludeProductId]);
    return attachProductImages($stmt->fetchAll());
}

/** Saves a Contact form submission. */
function createContactMessage($name, $email, $phone, $subject, $message) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?,?,?,?,?)');
    $stmt->execute([$name, $email, $phone ?: null, $subject ?: null, $message]);
}



function approveProduct($productId, $adminId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('UPDATE products SET status = "approved", rejection_reason = NULL, approved_by = ?, approved_at = NOW() WHERE id = ?');
    $stmt->execute([$adminId, $productId]);
    notifyProductOwner($productId, 'product_approved', 'Your listing was approved and is now live.');
}

function toggleFeaturedProduct($productId) {
    $pdo = getDbConnection();
    $pdo->prepare('UPDATE products SET is_featured = 1 - is_featured WHERE id = ?')->execute([$productId]);
}

function rejectProduct($productId, $reason) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('UPDATE products SET status = "rejected", rejection_reason = ? WHERE id = ?');
    $stmt->execute([$reason, $productId]);
    notifyProductOwner($productId, 'product_rejected', 'Your listing was rejected: ' . $reason);
}

/** "Request Changes" — distinct from a hard rejection; the seller is expected to edit and resubmit. */
function requestProductChanges($productId, $reason) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('UPDATE products SET status = "changes_requested", rejection_reason = ? WHERE id = ?');
    $stmt->execute([$reason, $productId]);
    notifyProductOwner($productId, 'product_changes_requested', 'Please update your listing: ' . $reason);
}

/** Admin-only: soft-hide a product without deleting it (distinct from rejection). */
function hideProduct($productId) {
    $pdo = getDbConnection();
    $pdo->prepare('UPDATE products SET status = "removed" WHERE id = ?')->execute([$productId]);
}

/** Admin-only: restore a hidden product back to approved. */
function restoreProduct($productId) {
    $pdo = getDbConnection();
    $pdo->prepare('UPDATE products SET status = "approved" WHERE id = ?')->execute([$productId]);
}

/** Toggle Sold Out / Available. Callable by the owner or an admin (ownership is checked by the caller). */
function toggleSoldOut($productId) {
    $pdo = getDbConnection();
    $pdo->prepare('UPDATE products SET sold_out = 1 - sold_out WHERE id = ?')->execute([$productId]);
    notifyProductOwner($productId, 'product_sold_out', null, true);
}

function deleteProductCompletely($productId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM product_images WHERE product_id = ?');
    $stmt->execute([$productId]);
    foreach ($stmt->fetchAll() as $img) {
        deleteProductImageFile($img);
    }
    $pdo->prepare('DELETE FROM products WHERE id = ?')->execute([$productId]);
}

/** Paginated product listing for admin/products.php, optionally filtered by status. */
function getProductsForAdmin($status, $page, $perPage) {
    $pdo = getDbConnection();
    $where = $status ? 'WHERE p.status = ?' : '';
    $params = $status ? [$status] : [];

    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM products p $where");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $offset = max(0, ($page - 1) * $perPage);
    $stmt = $pdo->prepare(PRODUCT_LIST_SELECT . " $where ORDER BY p.created_at DESC LIMIT $perPage OFFSET $offset");
    $stmt->execute($params);
    $products = attachProductImages($stmt->fetchAll());

    return ['products' => $products, 'total' => $total];
}



/** Count of products in one status ('pending','approved','rejected','sold','removed'). */
function countProductsByStatus($status) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM products WHERE status = ?');
    $stmt->execute([$status]);
    return (int) $stmt->fetchColumn();
}

function countAllProducts() {
    $pdo = getDbConnection();
    return (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
}

function countTotalUsers() {
    $pdo = getDbConnection();
    return (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
}

function countTotalCategories() {
    $pdo = getDbConnection();
    return (int) $pdo->query("SELECT COUNT(*) FROM categories WHERE status = 'active'")->fetchColumn();
}

function countUnreadContactMessages() {
    $pdo = getDbConnection();
    return (int) $pdo->query('SELECT COUNT(*) FROM contact_messages WHERE is_read = 0')->fetchColumn();
}

/** Newest pending listings — shown as a quick-review preview on the dashboard. */
function getRecentPendingProducts($limit = 5) {
    $pdo = getDbConnection();
    $stmt = $pdo->query(PRODUCT_LIST_SELECT . " WHERE p.status = 'pending' ORDER BY p.created_at ASC LIMIT " . (int) $limit);
    return attachProductImages($stmt->fetchAll());
}

/** Newest registered users — shown as a quick preview on the dashboard. */
function getRecentUsers($limit = 5) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT id, name, email, created_at FROM users ORDER BY created_at DESC LIMIT ?');
    $stmt->bindValue(1, (int) $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/* =====================================================================
   ADMIN — CATEGORY & SUBCATEGORY MANAGEMENT
   ===================================================================== */

/** All categories regardless of status, with live subcategory/product counts (for admin/categories.php). */
function getAllCategoriesForAdmin() {
    $pdo = getDbConnection();
    $sql = "SELECT c.*,
              (SELECT COUNT(*) FROM subcategories s WHERE s.category_id = c.id) AS subcategory_count,
              (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count
            FROM categories c ORDER BY c.sort_order, c.name";
    return $pdo->query($sql)->fetchAll();
}

/** All subcategories (any status) for one category, with product counts. */
function getAllSubcategoriesForAdmin($categoryId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(
        "SELECT s.*, (SELECT COUNT(*) FROM products p WHERE p.subcategory_id = s.id) AS product_count
         FROM subcategories s WHERE s.category_id = ? ORDER BY s.sort_order, s.name"
    );
    $stmt->execute([$categoryId]);
    return $stmt->fetchAll();
}

function getSubcategoryById($id) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM subcategories WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

function createCategory($name, $icon, $sortOrder) {
    $pdo = getDbConnection();
    $slug = uniqueCategorySlug($name);
    $stmt = $pdo->prepare('INSERT INTO categories (name, slug, icon, sort_order) VALUES (?,?,?,?)');
    $stmt->execute([$name, $slug, $icon ?: '📦', $sortOrder]);
    return (int) $pdo->lastInsertId();
}

function updateCategory($id, $name, $icon, $sortOrder, $status) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('UPDATE categories SET name = ?, icon = ?, sort_order = ?, status = ? WHERE id = ?');
    $stmt->execute([$name, $icon ?: '📦', $sortOrder, $status, $id]);
}

/** Returns true on success, or a string error message if the category can't be deleted (has products). */
function deleteCategory($id) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM products WHERE category_id = ?');
    $stmt->execute([$id]);
    if ((int) $stmt->fetchColumn() > 0) {
        return 'This category still has products listed under it — reassign or remove those first.';
    }
    $pdo->prepare('DELETE FROM categories WHERE id = ?')->execute([$id]);
    return true;
}

function createSubcategory($categoryId, $name, $sortOrder) {
    $pdo = getDbConnection();
    $slug = uniqueSubcategorySlug($categoryId, $name);
    $stmt = $pdo->prepare('INSERT INTO subcategories (category_id, name, slug, sort_order) VALUES (?,?,?,?)');
    $stmt->execute([$categoryId, $name, $slug, $sortOrder]);
    return (int) $pdo->lastInsertId();
}

function updateSubcategory($id, $name, $sortOrder, $status) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('UPDATE subcategories SET name = ?, sort_order = ?, status = ? WHERE id = ?');
    $stmt->execute([$name, $sortOrder, $status, $id]);
}

function deleteSubcategory($id) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM products WHERE subcategory_id = ?');
    $stmt->execute([$id]);
    if ((int) $stmt->fetchColumn() > 0) {
        return 'This sub category still has products listed under it — reassign or remove those first.';
    }
    $pdo->prepare('DELETE FROM subcategories WHERE id = ?')->execute([$id]);
    return true;
}

function uniqueCategorySlug($name) {
    $pdo = getDbConnection();
    $base = slugify($name);
    $slug = $base;
    $i = 1;
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM categories WHERE slug = ?');
    while (true) {
        $stmt->execute([$slug]);
        if ((int) $stmt->fetchColumn() === 0) return $slug;
        $i++;
        $slug = $base . '-' . $i;
    }
}

function uniqueSubcategorySlug($categoryId, $name) {
    $pdo = getDbConnection();
    $base = slugify($name);
    $slug = $base;
    $i = 1;
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM subcategories WHERE category_id = ? AND slug = ?');
    while (true) {
        $stmt->execute([$categoryId, $slug]);
        if ((int) $stmt->fetchColumn() === 0) return $slug;
        $i++;
        $slug = $base . '-' . $i;
    }
}

/* =====================================================================
   ADMIN — USER MANAGEMENT
   ===================================================================== */

function getUsersForAdmin($search, $page, $perPage) {
    $pdo = getDbConnection();
    $where = '';
    $params = [];
    if ($search !== '') {
        $where = 'WHERE name LIKE ? OR email LIKE ? OR phone LIKE ?';
        $params = ["%$search%", "%$search%", "%$search%"];
    }

    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM users $where");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $offset = max(0, ($page - 1) * $perPage);
    $stmt = $pdo->prepare(
        "SELECT u.*, (SELECT COUNT(*) FROM products p WHERE p.user_id = u.id) AS product_count
         FROM users u $where ORDER BY u.created_at DESC LIMIT $perPage OFFSET $offset"
    );
    $stmt->execute($params);
    return ['users' => $stmt->fetchAll(), 'total' => $total];
}

function setUserStatus($userId, $status) {
    $pdo = getDbConnection();
    $pdo->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$status, $userId]);
}

/* =====================================================================
   ADMIN — TESTIMONIAL MANAGEMENT
   ===================================================================== */

function getAllTestimonialsForAdmin() {
    $pdo = getDbConnection();
    return $pdo->query('SELECT * FROM testimonials ORDER BY sort_order, created_at DESC')->fetchAll();
}

function createTestimonial($name, $location, $message, $rating, $sortOrder) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('INSERT INTO testimonials (name, location, message, rating, sort_order) VALUES (?,?,?,?,?)');
    $stmt->execute([$name, $location, $message, $rating, $sortOrder]);
}

function updateTestimonial($id, $name, $location, $message, $rating, $sortOrder, $isActive) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('UPDATE testimonials SET name=?, location=?, message=?, rating=?, sort_order=?, is_active=? WHERE id=?');
    $stmt->execute([$name, $location, $message, $rating, $sortOrder, $isActive, $id]);
}

function deleteTestimonial($id) {
    $pdo = getDbConnection();
    $pdo->prepare('DELETE FROM testimonials WHERE id = ?')->execute([$id]);
}

function getTestimonialById($id) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM testimonials WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

/* =====================================================================
   ADMIN — CONTACT MESSAGES
   ===================================================================== */

function getContactMessagesForAdmin($filter, $page, $perPage) {
    $pdo = getDbConnection();
    $where = $filter === 'unread' ? 'WHERE is_read = 0' : '';

    $countStmt = $pdo->query("SELECT COUNT(*) FROM contact_messages $where");
    $total = (int) $countStmt->fetchColumn();

    $offset = max(0, ($page - 1) * $perPage);
    $stmt = $pdo->query("SELECT * FROM contact_messages $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset");
    return ['messages' => $stmt->fetchAll(), 'total' => $total];
}

function markContactMessageRead($id) {
    $pdo = getDbConnection();
    $pdo->prepare('UPDATE contact_messages SET is_read = 1 WHERE id = ?')->execute([$id]);
}

function deleteContactMessage($id) {
    $pdo = getDbConnection();
    $pdo->prepare('DELETE FROM contact_messages WHERE id = ?')->execute([$id]);
}

/* =====================================================================
   ADMIN — SITE SETTINGS
   ===================================================================== */

/** Every setting as a flat key => value array (for pre-filling admin forms). */
function getAllSettings() {
    $pdo = getDbConnection();
    $settings = [];
    foreach ($pdo->query('SELECT setting_key, setting_value FROM settings') as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    return $settings;
}

/** Upserts one setting. Also busts getSetting()'s static cache so the change is reflected immediately. */
function setSetting($key, $value) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(
        'INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
    );
    $stmt->execute([$key, $value]);
}

/* =====================================================================
   NOTIFICATIONS
   ===================================================================== */

/**
 * Creates a notification. For product_sold_out, $isToggle=true switches
 * the message automatically based on the product's current sold_out state
 * (since the caller just flipped it and doesn't know the new value here).
 */
function createNotification($recipientType, $recipientId, $productId, $type, $message) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('INSERT INTO notifications (recipient_type, recipient_id, product_id, type, message) VALUES (?,?,?,?,?)');
    $stmt->execute([$recipientType, $recipientId, $productId, $type, $message]);
}

/** Notifies the owning user about something that happened to their product. */
function notifyProductOwner($productId, $type, $message, $isSoldOutToggle = false) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT user_id, title, sold_out FROM products WHERE id = ?');
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    if (!$product) return;

    if ($isSoldOutToggle) {
        $message = $product['sold_out']
            ? 'Your listing "' . $product['title'] . '" was marked Sold Out.'
            : 'Your listing "' . $product['title'] . '" was marked Available again.';
    } else {
        $message = '"' . $product['title'] . '": ' . $message;
    }

    createNotification('user', $product['user_id'], $productId, $type, $message);
}

function getNotifications($recipientType, $recipientId, $limit = 10) {
    $pdo = getDbConnection();
    if ($recipientType === 'admin') {
        $stmt = $pdo->prepare('SELECT * FROM notifications WHERE recipient_type = "admin" ORDER BY created_at DESC LIMIT ' . (int) $limit);
        $stmt->execute();
    } else {
        $stmt = $pdo->prepare('SELECT * FROM notifications WHERE recipient_type = "user" AND recipient_id = ? ORDER BY created_at DESC LIMIT ' . (int) $limit);
        $stmt->execute([$recipientId]);
    }
    return $stmt->fetchAll();
}

function countUnreadNotifications($recipientType, $recipientId) {
    $pdo = getDbConnection();
    if ($recipientType === 'admin') {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE recipient_type = "admin" AND is_read = 0');
        $stmt->execute();
    } else {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE recipient_type = "user" AND recipient_id = ? AND is_read = 0');
        $stmt->execute([$recipientId]);
    }
    return (int) $stmt->fetchColumn();
}

function markAllNotificationsRead($recipientType, $recipientId) {
    $pdo = getDbConnection();
    if ($recipientType === 'admin') {
        $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE recipient_type = "admin"')->execute();
    } else {
        $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE recipient_type = "user" AND recipient_id = ?')->execute([$recipientId]);
    }
}

/* =====================================================================
   IMAGE MANAGEMENT (admin + owner)
   ===================================================================== */

/** Raw image rows (with ids) for a product — needed for delete/replace/set-cover, unlike attachProductImages()'s URL-only array. */
function getProductImageRows($productId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC');
    $stmt->execute([$productId]);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['url'] = productImageUrl($row);
    }
    return $rows;
}

function countProductImages($productId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM product_images WHERE product_id = ?');
    $stmt->execute([$productId]);
    return (int) $stmt->fetchColumn();
}

/** Deletes one image (file + row). If it was the cover image, promotes the next one automatically. */
function deleteProductImageById($imageId) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM product_images WHERE id = ?');
    $stmt->execute([$imageId]);
    $image = $stmt->fetch();
    if (!$image) return;

    deleteProductImageFile($image);
    $pdo->prepare('DELETE FROM product_images WHERE id = ?')->execute([$imageId]);

    if ($image['is_primary']) {
        $next = $pdo->prepare('SELECT id FROM product_images WHERE product_id = ? ORDER BY sort_order ASC LIMIT 1');
        $next->execute([$image['product_id']]);
        $nextId = $next->fetchColumn();
        if ($nextId) {
            $pdo->prepare('UPDATE product_images SET is_primary = 1 WHERE id = ?')->execute([$nextId]);
        }
    }
}

/** Deletes every image (files + rows) for a product. */
function deleteAllProductImages($productId) {
    foreach (getProductImageRows($productId) as $img) {
        deleteProductImageFile($img);
    }
    $pdo = getDbConnection();
    $pdo->prepare('DELETE FROM product_images WHERE product_id = ?')->execute([$productId]);
}

/** Sets one image as the cover (is_primary) and un-sets all others for that product. */
function setCoverImage($productId, $imageId) {
    $pdo = getDbConnection();
    $pdo->prepare('UPDATE product_images SET is_primary = 0 WHERE product_id = ?')->execute([$productId]);
    $pdo->prepare('UPDATE product_images SET is_primary = 1 WHERE id = ? AND product_id = ?')->execute([$imageId, $productId]);
}

/** Replaces the file behind an existing image row with a newly uploaded one (keeps its position/cover status). */
function replaceProductImageFile($imageId, array $newImageData) {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('SELECT * FROM product_images WHERE id = ?');
    $stmt->execute([$imageId]);
    $old = $stmt->fetch();
    if (!$old) return;

    deleteProductImageFile($old);
    $pdo->prepare('UPDATE product_images SET filename = ?, upload_year = ?, upload_month = ? WHERE id = ?')
        ->execute([$newImageData['filename'], $newImageData['upload_year'], $newImageData['upload_month'], $imageId]);
}

/** Adds new images to an existing product, respecting the MAX_IMAGES_PER_PRODUCT cap. Returns error strings if the cap would be exceeded. */
function addImagesToProduct($productId, array $newImages) {
    $currentCount = countProductImages($productId);
    $pdo = getDbConnection();
    $stmt = $pdo->prepare('INSERT INTO product_images (product_id, filename, upload_year, upload_month, is_primary, sort_order) VALUES (?,?,?,?,?,?)');
    $sortOrder = $currentCount;
    foreach ($newImages as $img) {
        if ($currentCount + 1 > MAX_IMAGES_PER_PRODUCT) break;
        $stmt->execute([$productId, $img['filename'], $img['upload_year'], $img['upload_month'], $currentCount === 0 ? 1 : 0, $sortOrder]);
        $currentCount++;
        $sortOrder++;
    }
}

/* =====================================================================
   DASHBOARD COUNTS
   ===================================================================== */

function countSoldOutProducts() {
    $pdo = getDbConnection();
    return (int) $pdo->query('SELECT COUNT(*) FROM products WHERE sold_out = 1')->fetchColumn();
}

function countTotalImages() {
    $pdo = getDbConnection();
    return (int) $pdo->query('SELECT COUNT(*) FROM product_images')->fetchColumn();
}
