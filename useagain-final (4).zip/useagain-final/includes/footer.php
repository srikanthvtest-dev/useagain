</main>

<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-col">
      <div class="logo footer-logo">
        <span class="logo-mark">♻️</span>
        <span class="logo-text">Use<span class="logo-accent">Again</span></span>
      </div>
      <p>A marketplace to buy, sell and donate reusable products — helping your community save money and reduce waste, one item at a time.</p>
    </div>

    <div class="footer-col">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="<?= BASE_URL ?>/index.php">Home</a></li>
        <li><a href="<?= BASE_URL ?>/products.php">Browse Products</a></li>
        <li><a href="<?= BASE_URL ?>/post-product.php">Sell / Donate an Item</a></li>
        <li><a href="<?= BASE_URL ?>/about.php">About Us</a></li>
        <li><a href="<?= BASE_URL ?>/contact.php">Contact</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Categories</h4>
      <ul>
        <?php foreach (array_slice(getCategories(), 0, 6) as $cat): ?>
        <li><a href="<?= BASE_URL ?>/products.php?category=<?= htmlspecialchars($cat['slug']) ?>"><?= $cat['icon'] ?> <?= htmlspecialchars($cat['name']) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Get in Touch</h4>
      <ul class="footer-contact">
        <li>📧 <a href="mailto:<?= htmlspecialchars(getSetting('contact_email', CONTACT_EMAIL)) ?>"><?= htmlspecialchars(getSetting('contact_email', CONTACT_EMAIL)) ?></a></li>
        <li>📱 <a href="https://wa.me/<?= htmlspecialchars(getSetting('whatsapp_number', WHATSAPP_NUMBER)) ?>" target="_blank" rel="noopener">Chat on WhatsApp</a></li>
      </ul>
    </div>
  </div>

  <div class="footer-bottom">
    <div class="container">
      <p>&copy; <?= date('Y') ?> <?= htmlspecialchars(getSetting('site_name', SITE_NAME)) ?>. All rights reserved.</p>
    </div>
  </div>
</footer>

<a href="https://wa.me/<?= htmlspecialchars(getSetting('whatsapp_number', WHATSAPP_NUMBER)) ?>?text=<?= rawurlencode('Hi, I have a question about UseAgain.') ?>" target="_blank" rel="noopener" class="floating-whatsapp" aria-label="Chat on WhatsApp">💬</a>
<button type="button" class="scroll-to-top" id="scrollTopBtn" aria-label="Scroll to top">↑</button>

<script src="<?= BASE_URL ?>/assets/js/script.js?v=<?= ASSET_VERSION ?>"></script>
</body>
</html>
