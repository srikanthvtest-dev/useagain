<?php
/**
 * UseAgain — Product Image Upload
 * ---------------------------------------------------------------------
 * Matches the product_images schema exactly: one row per photo, storing
 * only filename + upload_year + upload_month (no separate thumbnail
 * column) — so instead of generating a second file, each image is
 * resized down to MAX_IMAGE_DIMENSION on the way in and re-encoded at
 * IMAGE_JPEG_QUALITY, keeping file sizes reasonable for GoDaddy shared
 * hosting without needing a second stored file per photo.
 *
 * Depends on constants already defined in config/config.php:
 *   UPLOAD_DIR, MAX_IMAGES_PER_PRODUCT, MAX_IMAGE_DIMENSION, IMAGE_JPEG_QUALITY
 */

const PRODUCT_IMAGE_MAX_BYTES = 5 * 1024 * 1024; // 5MB per uploaded file

const PRODUCT_IMAGE_ALLOWED_MIME = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/webp' => 'webp',
];

/**
 * Validates + saves every non-empty slot in a $_FILES['images'] array
 * (from <input type="file" name="images[]" multiple>).
 *
 * @return array List of ['filename' => ..., 'upload_year' => 'YYYY', 'upload_month' => 'MM']
 *               for each successfully saved image. Errors are appended to $errors by reference.
 */
function handleProductImageUploads(array $filesField, array &$errors): array
{
    $saved = [];

    $names = array_filter($filesField['name'] ?? [], fn($n) => $n !== '');
    $count = count($names);

    if ($count < 1) {
        $errors[] = 'Please upload at least one photo of your item.';
        return $saved;
    }
    if ($count > MAX_IMAGES_PER_PRODUCT) {
        $errors[] = 'You can upload a maximum of ' . MAX_IMAGES_PER_PRODUCT . ' photos.';
        return $saved;
    }

    $total = count($filesField['name']);
    for ($i = 0; $i < $total; $i++) {
        if ($filesField['error'][$i] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        $single = [
            'name'     => $filesField['name'][$i],
            'type'     => $filesField['type'][$i],
            'tmp_name' => $filesField['tmp_name'][$i],
            'error'    => $filesField['error'][$i],
            'size'     => $filesField['size'][$i],
        ];
        $result = handleSingleProductImageUpload($single, $errors);
        if ($result !== null) {
            $saved[] = $result;
        }
    }

    return $saved;
}

function handleSingleProductImageUpload(array $file, array &$errors): ?array
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = htmlspecialchars($file['name']) . ' failed to upload (error code ' . $file['error'] . ').';
        return null;
    }

    if ($file['size'] > PRODUCT_IMAGE_MAX_BYTES) {
        $errors[] = htmlspecialchars($file['name']) . ' is larger than 5MB.';
        return null;
    }

    // Never trust the client-supplied MIME type — sniff the real content.
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset(PRODUCT_IMAGE_ALLOWED_MIME[$mime])) {
        $errors[] = htmlspecialchars($file['name']) . ' must be a JPEG, PNG, or WEBP image.';
        return null;
    }

    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false) {
        $errors[] = htmlspecialchars($file['name']) . ' could not be read as a valid image.';
        return null;
    }

    $year = date('Y');
    $month = date('m');
    $destDir = UPLOAD_DIR . $year . '/' . $month . '/';

    if (!is_dir($destDir) && !mkdir($destDir, 0755, true) && !is_dir($destDir)) {
        $errors[] = 'Server could not create the upload folder. Please contact support.';
        return null;
    }

    $ext = PRODUCT_IMAGE_ALLOWED_MIME[$mime];
    $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    $destPath = $destDir . $filename;

    if (!resizeAndSaveImage($file['tmp_name'], $destPath, $mime, MAX_IMAGE_DIMENSION, IMAGE_JPEG_QUALITY)) {
        $errors[] = 'Failed to process ' . htmlspecialchars($file['name']) . '.';
        return null;
    }

    return [
        'filename'     => $filename,
        'upload_year'  => $year,
        'upload_month' => $month,
    ];
}

/**
 * Resizes an image so its longest side is at most $maxDimension (never
 * upscales), then writes it back out in its original format.
 */
function resizeAndSaveImage(string $sourcePath, string $destPath, string $mime, int $maxDimension, int $jpegQuality): bool
{
    if (!extension_loaded('gd')) {
        // GD isn't available on this server — fall back to copying the
        // original file as-is rather than crashing the whole page.
        // (Enable the GD extension for proper resizing/compression.)
        return copy($sourcePath, $destPath);
    }

    [$origWidth, $origHeight] = getimagesize($sourcePath);

    $source = match ($mime) {
        'image/png'  => @imagecreatefrompng($sourcePath),
        'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($sourcePath) : @imagecreatefromjpeg($sourcePath),
        default      => @imagecreatefromjpeg($sourcePath),
    };
    if (!$source) {
        return false;
    }

    $longestSide = max($origWidth, $origHeight);
    $scale = $longestSide > $maxDimension ? $maxDimension / $longestSide : 1;
    $newWidth = max(1, (int) round($origWidth * $scale));
    $newHeight = max(1, (int) round($origHeight * $scale));

    $canvas = imagecreatetruecolor($newWidth, $newHeight);

    if ($mime === 'image/png') {
        imagealphablending($canvas, false);
        imagesavealpha($canvas, true);
        $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
        imagefilledrectangle($canvas, 0, 0, $newWidth, $newHeight, $transparent);
    }

    imagecopyresampled($canvas, $source, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

    $result = match ($mime) {
        'image/png'  => imagepng($canvas, $destPath, 8),
        'image/webp' => function_exists('imagewebp') ? imagewebp($canvas, $destPath, $jpegQuality) : imagejpeg($canvas, $destPath, $jpegQuality),
        default      => imagejpeg($canvas, $destPath, $jpegQuality),
    };

    imagedestroy($source);
    imagedestroy($canvas);

    if ($result) {
        chmod($destPath, 0644);
    }

    return (bool) $result;
}

/** Deletes an uploaded image's file from disk given its DB row (filename/year/month). */
function deleteProductImageFile(array $imageRow): void
{
    $path = UPLOAD_DIR . $imageRow['upload_year'] . '/' . $imageRow['upload_month'] . '/' . $imageRow['filename'];
    if (is_file($path)) {
        @unlink($path);
    }
}
