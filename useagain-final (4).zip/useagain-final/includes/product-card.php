<?php
/**
 * Reusable Product Card. Expects $p (a product row with 'images' attached
 * via attachProductImages()) to be set before including this file.
 */
$img = $p['images'][0] ?? 'https://placehold.co/600x450/EEF2F0/3A443E?text=No+Image';
$isDonate = ($p['listing_type'] ?? 'sell') === 'donate';
?>
<div class="product-card <?= !empty($p['sold_out']) ? 'is-sold-out' : '' ?>">
  <a href="<?= BASE_URL ?>/product-details.php?slug=<?= urlencode($p['slug']) ?>" class="thumb">
    <img src="<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($p['title']) ?>" loading="lazy">
    <?php if (!empty($p['sold_out'])): ?>
      <span class="badge badge-sold-out">Sold Out</span>
    <?php else: ?>
      <span class="badge <?= $isDonate ? 'badge-donate' : 'badge-sell' ?>"><?= $isDonate ? 'Donation' : 'For Sale' ?></span>
    <?php endif; ?>
    <span class="badge-condition"><?= htmlspecialchars($p['condition_type'] ?? '') ?></span>
  </a>
  <div class="product-info">
    <span class="cat-tag"><?= htmlspecialchars($p['category_icon'] ?? '') ?> <?= htmlspecialchars($p['subcategory_name'] ?? $p['category_name'] ?? '') ?></span>
    <h3><a href="<?= BASE_URL ?>/product-details.php?slug=<?= urlencode($p['slug']) ?>"><?= htmlspecialchars($p['title']) ?></a></h3>
    <?php if ($isDonate): ?>
      <div class="price donate">🎁 Free — Donation</div>
    <?php else: ?>
      <div class="price"><?= htmlspecialchars(formatPrice($p['price']) ?? 'Price on request') ?></div>
    <?php endif; ?>
    <span class="location">📍 <?= htmlspecialchars($p['area'] ?? '') ?>, <?= htmlspecialchars($p['city'] ?? '') ?></span>
    <a href="<?= BASE_URL ?>/product-details.php?slug=<?= urlencode($p['slug']) ?>" class="btn btn-outline btn-block btn-sm">View Details</a>
  </div>
</div>
