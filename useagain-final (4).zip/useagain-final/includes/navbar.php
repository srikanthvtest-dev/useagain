<?php
$currentPage = basename($_SERVER['SCRIPT_NAME']);
$user = currentUser();
function navActive($page, $current) { return $page === $current ? 'active' : ''; }
$activeCategorySlug = $_GET['category'] ?? '';
?>
<header class="site-header">
  <div class="navbar-top">
    <div class="container navbar">
      <a href="<?= BASE_URL ?>/index.php" class="logo">
        <svg class="logo-mark" width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="15" cy="15" r="15" fill="#1F9D55"/>
          <path d="M15 6.5c-3 0-5.6 1.7-6.9 4.2" stroke="#fff" stroke-width="2" stroke-linecap="round" fill="none"/>
          <path d="M22.8 12.8c0.5 3-0.8 6-3.5 7.9" stroke="#fff" stroke-width="2" stroke-linecap="round" fill="none"/>
          <path d="M11 22.6c-2.9-0.8-5-3.1-5.6-6" stroke="#fff" stroke-width="2" stroke-linecap="round" fill="none"/>
          <path d="M8.1 10.7l-1 2.6 2.7-0.4" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
          <path d="M19.3 20.7l1.1-2.6-2.7 0.3" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
          <path d="M5.4 16.6l-0.9-2.7 2.7 0.6" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
        </svg>
        <span class="logo-text">Use<span class="logo-accent">Again</span></span>
      </a>

      <form class="navbar-search" method="get" action="<?= BASE_URL ?>/products.php">
        <input type="text" name="q" placeholder="Search for toys, furniture, books, vehicles..." value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
        <button type="submit" aria-label="Search">Search</button>
      </form>

      <button type="button" class="nav-toggle" id="navToggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="navLinks">
        <span></span><span></span><span></span>
      </button>

      <nav class="nav-links" id="navLinks">
        <a href="<?= BASE_URL ?>/index.php" class="<?= navActive('index.php', $currentPage) ?>">Home</a>
        <a href="<?= BASE_URL ?>/products.php" class="<?= navActive('products.php', $currentPage) ?>">Search</a>
        <a href="<?= BASE_URL ?>/about.php" class="<?= navActive('about.php', $currentPage) ?>">About</a>
        <a href="<?= BASE_URL ?>/contact.php" class="<?= navActive('contact.php', $currentPage) ?>">Contact</a>

        <?php if ($user): ?>
          <div class="nav-dropdown">
            <button type="button" class="nav-dropdown-trigger account-trigger">
              <span class="account-avatar"><?= htmlspecialchars(mb_substr($user['name'], 0, 1)) ?></span>
              <?= htmlspecialchars(explode(' ', $user['name'])[0]) ?> <span class="caret">▾</span>
            </button>
            <div class="nav-dropdown-menu nav-dropdown-menu-right">
              <a href="<?= BASE_URL ?>/my-account.php" class="nav-dropdown-item">My Account</a>
              <a href="<?= BASE_URL ?>/my-account.php#listings" class="nav-dropdown-item">My Listings</a>
              <a href="<?= BASE_URL ?>/logout.php" class="nav-dropdown-item">Logout</a>
            </div>
          </div>
        <?php else: ?>
          <a href="<?= BASE_URL ?>/login.php" class="<?= navActive('login.php', $currentPage) ?>">Login</a>
        <?php endif; ?>

        <a href="<?= BASE_URL ?>/post-product.php" class="btn-post-nav <?= navActive('post-product.php', $currentPage) ?>">Sell / Donate</a>
      </nav>
    </div>
  </div>

  <!-- ================= Horizontal category bar ================= -->
  <div class="category-bar">
    <div class="container category-bar-row">
      <a href="<?= BASE_URL ?>/products.php" class="category-bar-item <?= ($currentPage === 'products.php' && $activeCategorySlug === '') ? 'active' : '' ?>">
        <span class="category-bar-icon">🔎</span> All
      </a>
      <?php foreach (getCategories() as $cat): ?>
        <a href="<?= BASE_URL ?>/products.php?category=<?= htmlspecialchars($cat['slug']) ?>" class="category-bar-item <?= ($currentPage === 'products.php' && $activeCategorySlug === $cat['slug']) ? 'active' : '' ?>">
          <span class="category-bar-icon"><?= $cat['icon'] ?></span> <?= htmlspecialchars($cat['name']) ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</header>
