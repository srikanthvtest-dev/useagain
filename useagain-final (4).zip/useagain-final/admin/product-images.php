<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/image-upload.php';
requireAdminLogin();

$productId = (int) ($_GET['id'] ?? $_POST['product_id'] ?? 0);
$product = $productId ? getProductById($productId) : null;

if (!$product) {
    header('Location: ' . BASE_URL . '/admin/products.php');
    exit;
}

$errors = [];
$notice = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_verify($_POST['csrf_token'] ?? '')) {
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'delete_image') {
        $imageId = (int) ($_POST['image_id'] ?? 0);
        if (countProductImages($productId) <= 1) {
            $errors[] = 'A listing needs at least one photo — add a replacement before deleting the last one.';
        } else {
            deleteProductImageById($imageId);
            $notice = 'Image deleted.';
        }
    } elseif ($formAction === 'set_cover') {
        setCoverImage($productId, (int) ($_POST['image_id'] ?? 0));
        $notice = 'Cover photo updated.';
    } elseif ($formAction === 'replace_image') {
        $imageId = (int) ($_POST['image_id'] ?? 0);
        if (!empty($_FILES['replacement']['name'])) {
            $uploadErrors = [];
            $result = handleSingleProductImageUpload($_FILES['replacement'], $uploadErrors);
            if ($result) {
                replaceProductImageFile($imageId, $result);
                $notice = 'Photo replaced.';
            } else {
                $errors = array_merge($errors, $uploadErrors);
            }
        } else {
            $errors[] = 'Please choose a file to replace this photo with.';
        }
    } elseif ($formAction === 'add_images') {
        $existing = countProductImages($productId);
        $remaining = MAX_IMAGES_PER_PRODUCT - $existing;
        if ($remaining <= 0) {
            $errors[] = 'This listing already has the maximum of ' . MAX_IMAGES_PER_PRODUCT . ' photos.';
        } elseif (empty($_FILES['new_images']['name'][0])) {
            $errors[] = 'Please choose at least one photo to add.';
        } else {
            $uploadErrors = [];
            $newImages = handleProductImageUploads($_FILES['new_images'], $uploadErrors);
            if ($newImages) {
                addImagesToProduct($productId, $newImages);
                $notice = count($newImages) . ' photo(s) added.';
            }
            $errors = array_merge($errors, $uploadErrors);
        }
    }
}

$images = getProductImageRows($productId);

$pageTitle = 'Manage Images';
require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-section-head">
  <h2>🖼️ Photos — <?= htmlspecialchars($product['title']) ?></h2>
  <a href="<?= BASE_URL ?>/admin/edit-product.php?id=<?= $productId ?>" class="btn btn-outline btn-sm">&larr; Back to Edit Product</a>
</div>

<?php if ($notice): ?><div class="alert alert-success" style="margin-bottom:20px;"><?= htmlspecialchars($notice) ?></div><?php endif; ?>
<?php if ($errors): ?>
  <div class="alert alert-error" style="margin-bottom:20px;">
    <ul style="margin:0 0 0 20px;"><?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="image-manage-grid">
  <?php foreach ($images as $img): ?>
    <div class="image-manage-card">
      <div class="image-manage-preview">
        <img src="<?= htmlspecialchars(productImageUrl($img)) ?>" alt="">
        <?php if ($img['is_primary']): ?><span class="cover-badge">Cover Photo</span><?php endif; ?>
      </div>

      <div class="image-manage-actions">
        <?php if (!$img['is_primary']): ?>
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="form_action" value="set_cover">
            <input type="hidden" name="product_id" value="<?= $productId ?>">
            <input type="hidden" name="image_id" value="<?= $img['id'] ?>">
            <button type="submit" class="btn btn-sm btn-outline">Make Cover</button>
          </form>
        <?php endif; ?>

        <label class="btn btn-sm btn-outline" style="cursor:pointer;">
          Replace
          <form method="post" enctype="multipart/form-data" id="replaceForm<?= $img['id'] ?>" style="display:none;">
            <?= csrf_field() ?>
            <input type="hidden" name="form_action" value="replace_image">
            <input type="hidden" name="product_id" value="<?= $productId ?>">
            <input type="hidden" name="image_id" value="<?= $img['id'] ?>">
          </form>
          <input type="file" accept="image/jpeg,image/png,image/webp" style="display:none;"
                 onchange="var f=document.getElementById('replaceForm<?= $img['id'] ?>'); f.appendChild(this); f.submit();">
        </label>

        <form method="post" onsubmit="return confirm('Delete this photo?');">
          <?= csrf_field() ?>
          <input type="hidden" name="form_action" value="delete_image">
          <input type="hidden" name="product_id" value="<?= $productId ?>">
          <input type="hidden" name="image_id" value="<?= $img['id'] ?>">
          <button type="submit" class="btn btn-sm btn-outline" style="color:#B42323; border-color:#B42323;">Delete</button>
        </form>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php if (count($images) < MAX_IMAGES_PER_PRODUCT): ?>
  <div class="form-card" style="margin-left:0; margin-top:24px;">
    <h3 style="margin-bottom:12px;">Add More Photos (<?= count($images) ?> / <?= MAX_IMAGES_PER_PRODUCT ?>)</h3>
    <form method="post" enctype="multipart/form-data">
      <?= csrf_field() ?>
      <input type="hidden" name="form_action" value="add_images">
      <input type="hidden" name="product_id" value="<?= $productId ?>">
      <input type="file" name="new_images[]" accept="image/jpeg,image/png,image/webp" multiple>
      <button type="submit" class="btn btn-primary" style="margin-top:12px;">Upload</button>
    </form>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
