<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/image-upload.php';
requireAdminLogin();

$productId = (int) ($_GET['id'] ?? $_POST['product_id'] ?? 0);
$product = $productId ? getProductById($productId) : null;

if (!$product) {
    header('Location: ' . BASE_URL . '/admin/products.php');
    exit;
}

$categories = getCategories();
$errors = [];
$old = [
    'category_id' => $product['category_id'], 'subcategory_id' => $product['subcategory_id'],
    'title' => $product['title'], 'description' => $product['description'], 'brand' => $product['brand'] ?? '',
    'condition_type' => $product['condition_type'], 'listing_type' => $product['listing_type'],
    'price' => $product['price'], 'is_negotiable' => $product['is_negotiable'] ? '1' : '',
    'address' => $product['address'], 'area' => $product['area'], 'city' => $product['city'],
    'state' => $product['state'], 'pincode' => $product['pincode'],
    'contact_number' => $product['contact_number'], 'whatsapp_number' => $product['whatsapp_number'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_verify($_POST['csrf_token'] ?? '')) {
    foreach (['category_id', 'subcategory_id', 'title', 'description', 'brand', 'condition_type', 'listing_type',
              'price', 'address', 'area', 'city', 'state', 'pincode', 'contact_number', 'whatsapp_number'] as $field) {
        $old[$field] = trim($_POST[$field] ?? '');
    }
    $old['is_negotiable'] = isset($_POST['is_negotiable']) ? '1' : '';
    $soldOut = isset($_POST['sold_out']) ? 1 : 0;

    $category = getCategoryById($old['category_id']);
    $subcategory = $category ? getSubcategoryForCategory($old['subcategory_id'], $category['id']) : null;

    if (!$category) $errors[] = 'Please select a valid main category.';
    if ($category && !$subcategory) $errors[] = 'Please select a valid sub category.';
    if (mb_strlen($old['title']) < 5) $errors[] = 'Please enter a title of at least 5 characters.';
    if (mb_strlen($old['description']) < 20) $errors[] = 'Please write a longer description.';
    if (!preg_match('/^[0-9]{4,10}$/', $old['pincode'])) $errors[] = 'Please enter a valid pincode.';

    if (empty($errors)) {
        updateProductFields($productId, [
            'category_id' => $category['id'], 'subcategory_id' => $subcategory['id'],
            'title' => $old['title'], 'description' => $old['description'], 'brand' => $old['brand'],
            'condition_type' => $old['condition_type'], 'listing_type' => $old['listing_type'],
            'price' => $old['listing_type'] === 'donate' ? null : (float) $old['price'],
            'is_negotiable' => $old['listing_type'] === 'donate' ? false : (bool) $old['is_negotiable'],
            'address' => $old['address'], 'area' => $old['area'], 'city' => $old['city'],
            'state' => $old['state'], 'pincode' => $old['pincode'],
            'contact_number' => $old['contact_number'], 'whatsapp_number' => $old['whatsapp_number'],
        ]);
        $pdo = getDbConnection();
        $pdo->prepare('UPDATE products SET sold_out = ? WHERE id = ?')->execute([$soldOut, $productId]);

        header('Location: ' . BASE_URL . '/admin/products.php?updated=1');
        exit;
    }
}

$pageTitle = 'Edit Product';
require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-section-head">
  <h2>✏️ Edit Product</h2>
  <div style="display:flex; gap:8px;">
    <a href="<?= BASE_URL ?>/admin/product-images.php?id=<?= $productId ?>" class="btn btn-outline btn-sm">🖼️ Manage Images</a>
    <a href="<?= BASE_URL ?>/product-details.php?slug=<?= urlencode($product['slug']) ?>" target="_blank" class="btn btn-outline btn-sm">View Live</a>
  </div>
</div>

<?php if (!empty($errors)): ?>
  <div class="alert alert-error"><ul style="margin:0 0 0 20px;"><?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<form class="form-card" method="post" style="margin-left:0;">
  <?= csrf_field() ?>
  <input type="hidden" name="product_id" value="<?= $productId ?>">

  <div class="form-row" style="margin-bottom:16px;">
    <label class="listing-toggle"><input type="radio" name="listing_type" value="sell" <?= $old['listing_type'] === 'sell' ? 'checked' : '' ?>> Sell</label>
    <label class="listing-toggle"><input type="radio" name="listing_type" value="donate" <?= $old['listing_type'] === 'donate' ? 'checked' : '' ?>> Donate</label>
    <label class="listing-toggle" style="margin-left:auto; background:#FDECEC; border-color:#B42323;">
      <input type="checkbox" name="sold_out" <?= $product['sold_out'] ? 'checked' : '' ?>> Sold Out
    </label>
  </div>

  <div class="form-group">
    <label>Product Name *</label>
    <input type="text" name="title" value="<?= htmlspecialchars($old['title']) ?>" required>
  </div>
  <div class="form-group">
    <label>Description *</label>
    <textarea name="description" rows="4" required><?= htmlspecialchars($old['description']) ?></textarea>
  </div>

  <div class="form-row">
    <div class="form-group">
      <label>Main Category *</label>
      <select id="category_id" name="category_id" required>
        <?php foreach ($categories as $cat): ?>
          <option value="<?= $cat['id'] ?>" <?= (string) $old['category_id'] === (string) $cat['id'] ? 'selected' : '' ?>><?= $cat['icon'] ?> <?= htmlspecialchars($cat['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label>Sub Category *</label>
      <select id="subcategory_id" name="subcategory_id" required>
        <option value="<?= $old['subcategory_id'] ?>" selected><?= htmlspecialchars(getSubcategoryById($old['subcategory_id'])['name'] ?? 'Current') ?></option>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group">
      <label>Condition</label>
      <select name="condition_type">
        <?php foreach (['New', 'Like New', 'Good', 'Fair'] as $c): ?>
          <option value="<?= $c ?>" <?= $old['condition_type'] === $c ? 'selected' : '' ?>><?= $c ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group"><label>Brand</label><input type="text" name="brand" value="<?= htmlspecialchars($old['brand']) ?>"></div>
  </div>

  <div class="form-row">
    <div class="form-group"><label>Price (₹)</label><input type="number" name="price" value="<?= htmlspecialchars((string) $old['price']) ?>"></div>
    <div class="form-group">
      <label>Negotiable?</label>
      <label class="listing-toggle" style="margin-right:10px;"><input type="radio" name="is_negotiable" value="1" <?= $old['is_negotiable'] === '1' ? 'checked' : '' ?>> Yes</label>
      <label class="listing-toggle"><input type="radio" name="is_negotiable" value="" <?= $old['is_negotiable'] !== '1' ? 'checked' : '' ?>> No</label>
    </div>
  </div>

  <div class="form-group"><label>Address</label><input type="text" name="address" value="<?= htmlspecialchars($old['address']) ?>"></div>
  <div class="form-row">
    <div class="form-group"><label>Area</label><input type="text" name="area" value="<?= htmlspecialchars($old['area']) ?>"></div>
    <div class="form-group"><label>City</label><input type="text" name="city" value="<?= htmlspecialchars($old['city']) ?>"></div>
  </div>
  <div class="form-row">
    <div class="form-group"><label>State</label><input type="text" name="state" value="<?= htmlspecialchars($old['state']) ?>"></div>
    <div class="form-group"><label>Pincode</label><input type="text" name="pincode" value="<?= htmlspecialchars($old['pincode']) ?>" required></div>
  </div>
  <div class="form-row">
    <div class="form-group"><label>Contact Number</label><input type="text" name="contact_number" value="<?= htmlspecialchars($old['contact_number']) ?>"></div>
    <div class="form-group"><label>WhatsApp Number</label><input type="text" name="whatsapp_number" value="<?= htmlspecialchars($old['whatsapp_number']) ?>"></div>
  </div>

  <button type="submit" class="btn btn-primary">Save Changes</button>
  <a href="<?= BASE_URL ?>/admin/products.php" class="btn btn-outline">Cancel</a>
</form>

<script>
document.getElementById('category_id').addEventListener('change', function () {
  var sel = document.getElementById('subcategory_id');
  fetch('<?= BASE_URL ?>/ajax-subcategories.php?category_id=' + encodeURIComponent(this.value))
    .then(function (r) { return r.json(); })
    .then(function (data) {
      sel.innerHTML = '<option value="">Select Sub Category</option>';
      (data.subcategories || []).forEach(function (sub) {
        var opt = document.createElement('option');
        opt.value = sub.id; opt.textContent = sub.name;
        sel.appendChild(opt);
      });
    });
});
</script>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
