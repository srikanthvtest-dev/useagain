<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdminLogin();

$saved = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_verify($_POST['csrf_token'] ?? '')) {
    setSetting('homepage_banner_title', trim($_POST['homepage_banner_title'] ?? ''));
    setSetting('homepage_banner_subtitle', trim($_POST['homepage_banner_subtitle'] ?? ''));
    setSetting('site_tagline', trim($_POST['site_tagline'] ?? ''));
    $saved = true;
}

$settings = getAllSettings();

$pageTitle = 'Manage Homepage';
require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-section-head"><h2>🏠 Homepage Content</h2></div>

<?php if ($saved): ?><div class="alert alert-success" style="margin-bottom:20px;">Homepage content updated.</div><?php endif; ?>

<div class="form-card" style="margin-left:0;">
  <form method="post">
    <?= csrf_field() ?>

    <div class="form-group">
      <label>Hero Headline</label>
      <input type="text" name="homepage_banner_title" value="<?= htmlspecialchars($settings['homepage_banner_title'] ?? '') ?>" placeholder="Give it a second life, not a place in the landfill.">
      <p class="form-note">Shown as the main heading on the homepage hero section. Leave blank to use the default.</p>
    </div>

    <div class="form-group">
      <label>Hero Subheading</label>
      <textarea name="homepage_banner_subtitle" rows="3" placeholder="Buy, sell and donate reusable products in your community."><?= htmlspecialchars($settings['homepage_banner_subtitle'] ?? '') ?></textarea>
    </div>

    <div class="form-group">
      <label>Site Tagline</label>
      <input type="text" name="site_tagline" value="<?= htmlspecialchars($settings['site_tagline'] ?? '') ?>" placeholder="Buy, Sell and Donate Reusable Products">
      <p class="form-note">Used in the browser tab title and meta description.</p>
    </div>

    <button type="submit" class="btn btn-primary">Save Homepage Content</button>
    <a href="<?= BASE_URL ?>/index.php" target="_blank" class="btn btn-outline">Preview Homepage</a>
  </form>
</div>

<div class="form-card" style="margin-left:0; margin-top:20px;">
  <h3 style="margin-bottom:14px;">Featured Products</h3>
  <p class="muted" style="margin-bottom:14px;">Homepage "Featured" listings are controlled from the Products screen — mark any approved listing as featured there.</p>
  <a href="<?= BASE_URL ?>/admin/products.php?status=approved" class="btn btn-outline">Go to Approved Products</a>
</div>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
