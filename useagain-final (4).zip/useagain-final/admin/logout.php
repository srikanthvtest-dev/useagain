<?php
require_once __DIR__ . '/../includes/functions.php';
logAdminOut();
header('Location: ' . BASE_URL . '/admin/login.php');
exit;
