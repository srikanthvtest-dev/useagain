<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdminLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (csrf_verify($_POST['csrf_token'] ?? '')) {
        $userId = (int) ($_POST['user_id'] ?? 0);
        $action = $_POST['action'] ?? '';
        if ($userId && $action === 'suspend') setUserStatus($userId, 'suspended');
        if ($userId && $action === 'activate') setUserStatus($userId, 'active');
    }
    header('Location: ' . BASE_URL . '/admin/users.php' . (!empty($_GET['q']) ? '?q=' . urlencode($_GET['q']) : ''));
    exit;
}

$search = trim($_GET['q'] ?? '');
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 20;
$result = getUsersForAdmin($search, $page, $perPage);
$users = $result['users'];
$totalPages = max(1, (int) ceil($result['total'] / $perPage));

$pageTitle = 'Users';
require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-section-head">
  <h2>👥 Registered Users (<?= number_format($result['total']) ?>)</h2>
  <form method="get" style="display:flex; gap:8px;">
    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search name, email, phone" style="padding:8px 12px; border:1px solid var(--card-border); border-radius:8px;">
    <button type="submit" class="btn btn-outline btn-sm">Search</button>
  </form>
</div>

<div class="admin-table-wrap">
  <table class="admin-table">
    <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Listings</th><th>Status</th><th>Joined</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><strong><?= htmlspecialchars($u['name']) ?></strong></td>
          <td class="muted"><?= htmlspecialchars($u['email']) ?></td>
          <td class="muted"><?= htmlspecialchars($u['phone']) ?></td>
          <td class="muted"><?= (int) $u['product_count'] ?></td>
          <td><span class="status-pill <?= $u['status'] === 'active' ? 'status-approved' : 'status-rejected' ?>"><?= ucfirst($u['status']) ?></span></td>
          <td class="muted"><?= timeAgo($u['created_at']) ?></td>
          <td>
            <form method="post" style="display:inline;">
              <?= csrf_field() ?>
              <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
              <?php if ($u['status'] === 'active'): ?>
                <input type="hidden" name="action" value="suspend">
                <button type="submit" class="btn btn-sm btn-outline" style="color:#B42323; border-color:#B42323;" onclick="return confirm('Suspend this user? They will not be able to log in.');">Suspend</button>
              <?php else: ?>
                <input type="hidden" name="action" value="activate">
                <button type="submit" class="btn btn-sm btn-primary">Reactivate</button>
              <?php endif; ?>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($users)): ?>
        <tr><td colspan="7" style="text-align:center; padding:30px; color:var(--gray-500);">No users found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php if ($totalPages > 1): ?>
  <div class="pagination">
    <?php if ($page > 1): ?><a href="?q=<?= urlencode($search) ?>&page=<?= $page - 1 ?>" class="btn btn-outline btn-sm">&larr; Prev</a><?php endif; ?>
    <span class="small-muted">Page <?= $page ?> of <?= $totalPages ?></span>
    <?php if ($page < $totalPages): ?><a href="?q=<?= urlencode($search) ?>&page=<?= $page + 1 ?>" class="btn btn-outline btn-sm">Next &rarr;</a><?php endif; ?>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
