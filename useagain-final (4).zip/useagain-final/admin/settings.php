<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdminLogin();

$saved = false;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_verify($_POST['csrf_token'] ?? '')) {
    $siteName = trim($_POST['site_name'] ?? '');
    $contactEmail = trim($_POST['contact_email'] ?? '');
    $whatsapp = preg_replace('/\D/', '', $_POST['whatsapp_number'] ?? '');

    if (mb_strlen($siteName) < 2) $errors[] = 'Please enter a site name.';
    if (!filter_var($contactEmail, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid contact email.';
    if (strlen($whatsapp) < 8) $errors[] = 'Please enter a valid WhatsApp number, including country code (e.g. 919876543210).';

    if (empty($errors)) {
        setSetting('site_name', $siteName);
        setSetting('contact_email', $contactEmail);
        setSetting('whatsapp_number', $whatsapp);
        $saved = true;
    }
}

$settings = getAllSettings();

$pageTitle = 'Site Settings';
require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-section-head"><h2>⚙️ Site Settings</h2></div>

<?php if ($saved): ?><div class="alert alert-success" style="margin-bottom:20px;">Settings updated.</div><?php endif; ?>
<?php if ($errors): ?>
  <div class="alert alert-error" style="margin-bottom:20px;">
    <ul style="margin:0 0 0 20px;"><?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="form-card" style="margin-left:0;">
  <form method="post">
    <?= csrf_field() ?>

    <div class="form-group">
      <label>Site Name</label>
      <input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? 'UseAgain') ?>" required>
    </div>

    <div class="form-group">
      <label>Contact Email</label>
      <input type="email" name="contact_email" value="<?= htmlspecialchars($settings['contact_email'] ?? '') ?>" required>
      <p class="form-note">Shown in the site footer and used as the reply-to for site notifications.</p>
    </div>

    <div class="form-group">
      <label>WhatsApp Number (with country code, digits only)</label>
      <input type="text" name="whatsapp_number" value="<?= htmlspecialchars($settings['whatsapp_number'] ?? '') ?>" required placeholder="919876543210">
      <p class="form-note">Used for the floating WhatsApp button and the "Donate" WhatsApp link on the homepage. This is separate from each seller's own WhatsApp number shown on their listings.</p>
    </div>

    <button type="submit" class="btn btn-primary">Save Settings</button>
  </form>
</div>

<div class="form-card" style="margin-left:0; margin-top:20px;">
  <h3 style="margin-bottom:10px;">Admin Account</h3>
  <p class="muted">Logged in as <strong><?= htmlspecialchars(currentAdmin()['name']) ?></strong> (<?= htmlspecialchars(currentAdmin()['email']) ?>).</p>
  <p class="muted" style="margin-top:8px;">To change your admin password or add another admin, do it directly via phpMyAdmin on the <code>admins</code> table for now (use PHP's <code>password_hash()</code> to generate the hash).</p>
</div>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
