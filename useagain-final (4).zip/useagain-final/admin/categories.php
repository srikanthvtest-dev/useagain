<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdminLogin();

$flash = '';
$flashType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        header('Location: ' . BASE_URL . '/admin/categories.php');
        exit;
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'add_category') {
        $name = trim($_POST['name'] ?? '');
        if (mb_strlen($name) < 2) {
            $flash = 'Please enter a category name.'; $flashType = 'error';
        } else {
            createCategory($name, trim($_POST['icon'] ?? ''), (int) ($_POST['sort_order'] ?? 0));
            header('Location: ' . BASE_URL . '/admin/categories.php');
            exit;
        }
    } elseif ($formAction === 'edit_category') {
        $id = (int) ($_POST['category_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        if ($id && mb_strlen($name) >= 2) {
            updateCategory($id, $name, trim($_POST['icon'] ?? ''), (int) ($_POST['sort_order'] ?? 0), $_POST['status'] === 'inactive' ? 'inactive' : 'active');
        }
        header('Location: ' . BASE_URL . '/admin/categories.php');
        exit;
    } elseif ($formAction === 'delete_category') {
        $id = (int) ($_POST['category_id'] ?? 0);
        $result = deleteCategory($id);
        header('Location: ' . BASE_URL . '/admin/categories.php' . ($result !== true ? '?error=' . urlencode($result) : ''));
        exit;
    } elseif ($formAction === 'add_subcategory') {
        $categoryId = (int) ($_POST['category_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        if ($categoryId && mb_strlen($name) >= 2) {
            createSubcategory($categoryId, $name, (int) ($_POST['sort_order'] ?? 0));
        }
        header('Location: ' . BASE_URL . '/admin/categories.php?open=' . $categoryId);
        exit;
    } elseif ($formAction === 'edit_subcategory') {
        $id = (int) ($_POST['subcategory_id'] ?? 0);
        $categoryId = (int) ($_POST['category_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        if ($id && mb_strlen($name) >= 2) {
            updateSubcategory($id, $name, (int) ($_POST['sort_order'] ?? 0), $_POST['status'] === 'inactive' ? 'inactive' : 'active');
        }
        header('Location: ' . BASE_URL . '/admin/categories.php?open=' . $categoryId);
        exit;
    } elseif ($formAction === 'delete_subcategory') {
        $id = (int) ($_POST['subcategory_id'] ?? 0);
        $categoryId = (int) ($_POST['category_id'] ?? 0);
        $result = deleteSubcategory($id);
        header('Location: ' . BASE_URL . '/admin/categories.php?open=' . $categoryId . ($result !== true ? '&error=' . urlencode($result) : ''));
        exit;
    }
}

if (!empty($_GET['error'])) { $flash = $_GET['error']; $flashType = 'error'; }

$categories = getAllCategoriesForAdmin();
$openCategoryId = (int) ($_GET['open'] ?? 0);
$editCategory = null;
if (!empty($_GET['edit'])) {
    foreach ($categories as $c) { if ((int) $c['id'] === (int) $_GET['edit']) { $editCategory = $c; break; } }
}

$pageTitle = 'Categories';
require_once __DIR__ . '/includes/admin-header.php';
?>

<?php if ($flash): ?><div class="alert alert-<?= $flashType === 'error' ? 'error' : 'success' ?>" style="margin-bottom:20px;"><?= htmlspecialchars($flash) ?></div><?php endif; ?>

<div class="admin-section-head">
  <h2>🗂️ Manage Categories</h2>
</div>

<div class="form-card" style="margin-bottom:26px; margin-left:0;">
  <h3 style="margin-bottom:16px;"><?= $editCategory ? 'Edit Category' : 'Add New Category' ?></h3>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="form_action" value="<?= $editCategory ? 'edit_category' : 'add_category' ?>">
    <?php if ($editCategory): ?><input type="hidden" name="category_id" value="<?= $editCategory['id'] ?>"><?php endif; ?>
    <div class="form-row">
      <div class="form-group">
        <label>Category Name *</label>
        <input type="text" name="name" required value="<?= htmlspecialchars($editCategory['name'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Icon (emoji)</label>
        <input type="text" name="icon" maxlength="4" value="<?= htmlspecialchars($editCategory['icon'] ?? '📦') ?>">
      </div>
      <div class="form-group">
        <label>Sort Order</label>
        <input type="number" name="sort_order" value="<?= htmlspecialchars((string) ($editCategory['sort_order'] ?? 0)) ?>">
      </div>
      <?php if ($editCategory): ?>
        <div class="form-group">
          <label>Status</label>
          <select name="status">
            <option value="active" <?= $editCategory['status'] === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $editCategory['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
          </select>
        </div>
      <?php endif; ?>
    </div>
    <button type="submit" class="btn btn-primary"><?= $editCategory ? 'Save Changes' : 'Add Category' ?></button>
    <?php if ($editCategory): ?><a href="<?= BASE_URL ?>/admin/categories.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="admin-table-wrap" style="margin-bottom:30px;">
  <table class="admin-table">
    <thead><tr><th>Category</th><th>Sub Categories</th><th>Products</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($categories as $cat): ?>
        <tr>
          <td><strong><?= $cat['icon'] ?> <?= htmlspecialchars($cat['name']) ?></strong></td>
          <td class="muted"><?= (int) $cat['subcategory_count'] ?></td>
          <td class="muted"><?= (int) $cat['product_count'] ?></td>
          <td><span class="status-pill <?= $cat['status'] === 'active' ? 'status-approved' : 'status-removed' ?>"><?= ucfirst($cat['status']) ?></span></td>
          <td class="admin-row-actions">
            <a href="<?= BASE_URL ?>/admin/categories.php?open=<?= $cat['id'] ?>" class="btn btn-sm btn-outline"><?= $openCategoryId === (int) $cat['id'] ? 'Hide' : 'Manage' ?> Sub Categories</a>
            <a href="<?= BASE_URL ?>/admin/categories.php?edit=<?= $cat['id'] ?>" class="btn btn-sm btn-outline">Edit</a>
            <form method="post" style="display:inline;" onsubmit="return confirm('Delete this category? This only works if no products use it.');">
              <?= csrf_field() ?>
              <input type="hidden" name="form_action" value="delete_category">
              <input type="hidden" name="category_id" value="<?= $cat['id'] ?>">
              <button type="submit" class="btn btn-sm btn-outline" style="color:#B42323; border-color:#B42323;">Delete</button>
            </form>
          </td>
        </tr>

        <?php if ($openCategoryId === (int) $cat['id']): ?>
          <tr>
            <td colspan="5" style="background:var(--gray-50); padding:20px;">
              <h4 style="margin-bottom:14px;">Sub Categories — <?= htmlspecialchars($cat['name']) ?></h4>

              <form method="post" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; margin-bottom:18px;">
                <?= csrf_field() ?>
                <input type="hidden" name="form_action" value="add_subcategory">
                <input type="hidden" name="category_id" value="<?= $cat['id'] ?>">
                <div class="form-group" style="margin-bottom:0;">
                  <label>New Sub Category Name</label>
                  <input type="text" name="name" required placeholder="e.g. Toys">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                  <label>Sort Order</label>
                  <input type="number" name="sort_order" value="0" style="width:90px;">
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Add</button>
              </form>

              <table class="admin-table">
                <thead><tr><th>Name</th><th>Products</th><th>Status</th><th></th></tr></thead>
                <tbody>
                  <?php foreach (getAllSubcategoriesForAdmin($cat['id']) as $sub): ?>
                    <tr>
                      <td>
                        <form method="post" style="display:flex; gap:8px; align-items:center;">
                          <?= csrf_field() ?>
                          <input type="hidden" name="form_action" value="edit_subcategory">
                          <input type="hidden" name="subcategory_id" value="<?= $sub['id'] ?>">
                          <input type="hidden" name="category_id" value="<?= $cat['id'] ?>">
                          <input type="text" name="name" value="<?= htmlspecialchars($sub['name']) ?>" style="max-width:220px;">
                          <input type="number" name="sort_order" value="<?= (int) $sub['sort_order'] ?>" style="width:70px;">
                          <select name="status">
                            <option value="active" <?= $sub['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $sub['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                          </select>
                          <button type="submit" class="btn btn-sm btn-outline">Save</button>
                        </form>
                      </td>
                      <td class="muted"><?= (int) $sub['product_count'] ?></td>
                      <td><span class="status-pill <?= $sub['status'] === 'active' ? 'status-approved' : 'status-removed' ?>"><?= ucfirst($sub['status']) ?></span></td>
                      <td>
                        <form method="post" onsubmit="return confirm('Delete this sub category?');">
                          <?= csrf_field() ?>
                          <input type="hidden" name="form_action" value="delete_subcategory">
                          <input type="hidden" name="subcategory_id" value="<?= $sub['id'] ?>">
                          <input type="hidden" name="category_id" value="<?= $cat['id'] ?>">
                          <button type="submit" class="btn btn-sm btn-outline" style="color:#B42323; border-color:#B42323;">Delete</button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </td>
          </tr>
        <?php endif; ?>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
