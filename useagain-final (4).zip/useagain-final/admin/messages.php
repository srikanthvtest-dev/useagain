<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdminLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (csrf_verify($_POST['csrf_token'] ?? '')) {
        $id = (int) ($_POST['message_id'] ?? 0);
        $action = $_POST['action'] ?? '';
        if ($id && $action === 'mark_read') markContactMessageRead($id);
        if ($id && $action === 'delete') deleteContactMessage($id);
    }
    header('Location: ' . BASE_URL . '/admin/messages.php' . (!empty($_GET['filter']) ? '?filter=' . urlencode($_GET['filter']) : ''));
    exit;
}

$filter = ($_GET['filter'] ?? '') === 'unread' ? 'unread' : '';
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 20;
$result = getContactMessagesForAdmin($filter, $page, $perPage);
$messages = $result['messages'];
$totalPages = max(1, (int) ceil($result['total'] / $perPage));

$pageTitle = 'Contact Messages';
require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-section-head">
  <h2>✉️ Contact Messages</h2>
  <div style="display:flex; gap:8px;">
    <a href="<?= BASE_URL ?>/admin/messages.php" class="btn btn-sm <?= $filter === '' ? 'btn-primary' : 'btn-outline' ?>">All</a>
    <a href="<?= BASE_URL ?>/admin/messages.php?filter=unread" class="btn btn-sm <?= $filter === 'unread' ? 'btn-primary' : 'btn-outline' ?>">Unread</a>
  </div>
</div>

<?php if (empty($messages)): ?>
  <div class="admin-table-wrap" style="padding:30px; text-align:center; color:var(--gray-500);">No messages here.</div>
<?php else: ?>
  <?php foreach ($messages as $m): ?>
    <div class="form-card" style="margin-left:0; margin-bottom:16px; <?= $m['is_read'] ? '' : 'border-left:4px solid var(--green);' ?>">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap;">
        <div>
          <strong><?= htmlspecialchars($m['name']) ?></strong>
          <?php if (!$m['is_read']): ?><span class="status-pill status-pending" style="margin-left:8px;">New</span><?php endif; ?>
          <div class="muted" style="font-size:0.85rem; margin-top:2px;">
            <?= htmlspecialchars($m['email']) ?><?= $m['phone'] ? ' · ' . htmlspecialchars($m['phone']) : '' ?> · <?= timeAgo($m['created_at']) ?>
          </div>
        </div>
        <div style="display:flex; gap:8px;">
          <?php if (!$m['is_read']): ?>
            <form method="post"><?= csrf_field() ?><input type="hidden" name="message_id" value="<?= $m['id'] ?>"><input type="hidden" name="action" value="mark_read"><button type="submit" class="btn btn-sm btn-outline">Mark Read</button></form>
          <?php endif; ?>
          <form method="post" onsubmit="return confirm('Delete this message?');"><?= csrf_field() ?><input type="hidden" name="message_id" value="<?= $m['id'] ?>"><input type="hidden" name="action" value="delete"><button type="submit" class="btn btn-sm btn-outline" style="color:#B42323; border-color:#B42323;">Delete</button></form>
        </div>
      </div>
      <?php if ($m['subject']): ?><p style="margin-top:12px; font-weight:600;"><?= htmlspecialchars($m['subject']) ?></p><?php endif; ?>
      <p style="margin-top:8px; color:var(--gray-700); white-space:pre-line;"><?= htmlspecialchars($m['message']) ?></p>
      <a href="mailto:<?= htmlspecialchars($m['email']) ?>" class="btn btn-sm btn-outline" style="margin-top:12px;">Reply by Email</a>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<?php if ($totalPages > 1): ?>
  <div class="pagination">
    <?php if ($page > 1): ?><a href="?filter=<?= $filter ?>&page=<?= $page - 1 ?>" class="btn btn-outline btn-sm">&larr; Prev</a><?php endif; ?>
    <span class="small-muted">Page <?= $page ?> of <?= $totalPages ?></span>
    <?php if ($page < $totalPages): ?><a href="?filter=<?= $filter ?>&page=<?= $page + 1 ?>" class="btn btn-outline btn-sm">Next &rarr;</a><?php endif; ?>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
