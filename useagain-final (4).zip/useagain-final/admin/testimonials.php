<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdminLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (csrf_verify($_POST['csrf_token'] ?? '')) {
        $action = $_POST['form_action'] ?? '';
        $rating = max(1, min(5, (int) ($_POST['rating'] ?? 5)));

        if ($action === 'add') {
            createTestimonial(trim($_POST['name'] ?? ''), trim($_POST['location'] ?? ''), trim($_POST['message'] ?? ''), $rating, (int) ($_POST['sort_order'] ?? 0));
        } elseif ($action === 'edit') {
            updateTestimonial(
                (int) ($_POST['testimonial_id'] ?? 0), trim($_POST['name'] ?? ''), trim($_POST['location'] ?? ''),
                trim($_POST['message'] ?? ''), $rating, (int) ($_POST['sort_order'] ?? 0), isset($_POST['is_active']) ? 1 : 0
            );
        } elseif ($action === 'delete') {
            deleteTestimonial((int) ($_POST['testimonial_id'] ?? 0));
        }
    }
    header('Location: ' . BASE_URL . '/admin/testimonials.php');
    exit;
}

$testimonials = getAllTestimonialsForAdmin();
$editTestimonial = null;
if (!empty($_GET['edit'])) {
    $editTestimonial = getTestimonialById((int) $_GET['edit']);
}

$pageTitle = 'Testimonials';
require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-section-head"><h2>💬 Homepage Testimonials</h2></div>

<div class="form-card" style="margin-bottom:26px; margin-left:0;">
  <h3 style="margin-bottom:16px;"><?= $editTestimonial ? 'Edit Testimonial' : 'Add New Testimonial' ?></h3>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="form_action" value="<?= $editTestimonial ? 'edit' : 'add' ?>">
    <?php if ($editTestimonial): ?><input type="hidden" name="testimonial_id" value="<?= $editTestimonial['id'] ?>"><?php endif; ?>

    <div class="form-row">
      <div class="form-group">
        <label>Name *</label>
        <input type="text" name="name" required value="<?= htmlspecialchars($editTestimonial['name'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Location</label>
        <input type="text" name="location" value="<?= htmlspecialchars($editTestimonial['location'] ?? '') ?>" placeholder="e.g. Hyderabad">
      </div>
    </div>

    <div class="form-group">
      <label>Message *</label>
      <textarea name="message" rows="3" required><?= htmlspecialchars($editTestimonial['message'] ?? '') ?></textarea>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label>Rating (1-5)</label>
        <select name="rating">
          <?php for ($r = 5; $r >= 1; $r--): ?>
            <option value="<?= $r ?>" <?= (int) ($editTestimonial['rating'] ?? 5) === $r ? 'selected' : '' ?>><?= str_repeat('⭐', $r) ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Sort Order</label>
        <input type="number" name="sort_order" value="<?= htmlspecialchars((string) ($editTestimonial['sort_order'] ?? 0)) ?>">
      </div>
      <?php if ($editTestimonial): ?>
        <div class="form-group">
          <label style="display:flex; align-items:center; gap:8px; margin-top:22px;">
            <input type="checkbox" name="is_active" style="width:auto;" <?= $editTestimonial['is_active'] ? 'checked' : '' ?>> Show on homepage
          </label>
        </div>
      <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-primary"><?= $editTestimonial ? 'Save Changes' : 'Add Testimonial' ?></button>
    <?php if ($editTestimonial): ?><a href="<?= BASE_URL ?>/admin/testimonials.php" class="btn btn-outline">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="admin-table-wrap">
  <table class="admin-table">
    <thead><tr><th>Name</th><th>Message</th><th>Rating</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($testimonials as $t): ?>
        <tr>
          <td><strong><?= htmlspecialchars($t['name']) ?></strong><br><span class="muted" style="font-size:0.8rem;"><?= htmlspecialchars($t['location']) ?></span></td>
          <td class="muted" style="max-width:340px;"><?= htmlspecialchars(mb_substr($t['message'], 0, 100)) ?><?= mb_strlen($t['message']) > 100 ? '…' : '' ?></td>
          <td><?= str_repeat('⭐', (int) $t['rating']) ?></td>
          <td><span class="status-pill <?= $t['is_active'] ? 'status-approved' : 'status-removed' ?>"><?= $t['is_active'] ? 'Visible' : 'Hidden' ?></span></td>
          <td class="admin-row-actions">
            <a href="<?= BASE_URL ?>/admin/testimonials.php?edit=<?= $t['id'] ?>" class="btn btn-sm btn-outline">Edit</a>
            <form method="post" style="display:inline;" onsubmit="return confirm('Delete this testimonial?');">
              <?= csrf_field() ?>
              <input type="hidden" name="form_action" value="delete">
              <input type="hidden" name="testimonial_id" value="<?= $t['id'] ?>">
              <button type="submit" class="btn btn-sm btn-outline" style="color:#B42323; border-color:#B42323;">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($testimonials)): ?>
        <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--gray-500);">No testimonials yet.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
