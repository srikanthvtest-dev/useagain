<?php
/**
 * Included by every admin/*.php page (except login.php).
 * Expects requireAdminLogin() to have already been called, and
 * $pageTitle to optionally be set before this include.
 */
$admin = currentAdmin();
$pageTitle = $pageTitle ?? 'Admin Dashboard';
$currentAdminPage = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?> - UseAgain Admin</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="<?= BASE_URL ?>/assets/images/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=<?= ASSET_VERSION ?>">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css?v=<?= ASSET_VERSION ?>">
</head>
<body class="admin-body">
<div class="admin-shell">
  <?php include __DIR__ . '/admin-sidebar.php'; ?>

  <div class="admin-main">
    <header class="admin-topbar">
      <button type="button" class="admin-menu-toggle" id="adminMenuToggle" aria-label="Toggle menu">☰</button>
      <h1><?= htmlspecialchars($pageTitle) ?></h1>
      <div class="admin-topbar-right">
        <span class="admin-whoami">👤 <?= htmlspecialchars($admin['name']) ?> <span class="admin-role-pill"><?= htmlspecialchars($admin['role']) ?></span></span>
        <a href="<?= BASE_URL ?>/admin/logout.php" class="btn btn-outline btn-sm">Logout</a>
      </div>
    </header>
    <main class="admin-content">
