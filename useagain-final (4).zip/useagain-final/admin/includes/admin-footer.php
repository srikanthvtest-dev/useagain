    </main>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/admin.js?v=<?= ASSET_VERSION ?>"></script>
</body>
</html>
