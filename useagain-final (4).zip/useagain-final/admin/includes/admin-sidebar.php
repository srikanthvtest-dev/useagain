<?php
function adminNavActive($page, $current) { return $page === $current ? 'active' : ''; }
$pendingCount = countProductsByStatus('pending');
?>
<aside class="admin-sidebar" id="adminSidebar">
  <div class="admin-sidebar-logo">
    <span class="logo-mark">♻️</span>
    <span class="logo-text">Use<span class="logo-accent">Again</span></span>
  </div>
  <p class="admin-sidebar-tag">Admin Panel</p>

  <nav class="admin-nav">
    <a href="<?= BASE_URL ?>/admin/dashboard.php" class="<?= adminNavActive('dashboard.php', $currentAdminPage) ?>">📊 Dashboard</a>
    <a href="<?= BASE_URL ?>/admin/products.php" class="<?= adminNavActive('products.php', $currentAdminPage) ?>">
      📦 Products
      <?php if ($pendingCount > 0): ?><span class="admin-nav-badge"><?= $pendingCount ?></span><?php endif; ?>
    </a>
    <a href="<?= BASE_URL ?>/admin/categories.php" class="<?= adminNavActive('categories.php', $currentAdminPage) ?>">🗂️ Categories</a>
    <a href="<?= BASE_URL ?>/admin/users.php" class="<?= adminNavActive('users.php', $currentAdminPage) ?>">👥 Users</a>
    <a href="<?= BASE_URL ?>/admin/testimonials.php" class="<?= adminNavActive('testimonials.php', $currentAdminPage) ?>">💬 Testimonials</a>
    <a href="<?= BASE_URL ?>/admin/messages.php" class="<?= adminNavActive('messages.php', $currentAdminPage) ?>">✉️ Contact Messages</a>
    <a href="<?= BASE_URL ?>/admin/homepage-settings.php" class="<?= adminNavActive('homepage-settings.php', $currentAdminPage) ?>">🏠 Manage Homepage</a>
    <a href="<?= BASE_URL ?>/admin/settings.php" class="<?= adminNavActive('settings.php', $currentAdminPage) ?>">⚙️ Site Settings</a>
  </nav>

  <div class="admin-sidebar-footer">
    <a href="<?= BASE_URL ?>/index.php" target="_blank">🔗 View Live Site</a>
  </div>
</aside>
