<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdminLogin();

$pageTitle = 'Dashboard';

$stats = [
    'total'    => countAllProducts(),
    'pending'  => countProductsByStatus('pending'),
    'approved' => countProductsByStatus('approved'),
    'rejected' => countProductsByStatus('rejected'),
    'users'    => countTotalUsers(),
];
$recentPending = getRecentPendingProducts(5);
$recentUsers = getRecentUsers(5);

require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-stats-grid">
  <div class="admin-stat-card">
    <div class="icon" style="background:var(--blue-light); color:var(--blue-dark);">📦</div>
    <strong><?= $stats['total'] ?></strong>
    <span>Total Products</span>
    <a href="<?= BASE_URL ?>/admin/products.php" class="stat-link">View all &rarr;</a>
  </div>
  <div class="admin-stat-card">
    <div class="icon" style="background:#FEF3C7; color:#92400E;">⏳</div>
    <strong><?= $stats['pending'] ?></strong>
    <span>Pending Approval</span>
    <a href="<?= BASE_URL ?>/admin/products.php?status=pending" class="stat-link">Review now &rarr;</a>
  </div>
  <div class="admin-stat-card">
    <div class="icon" style="background:var(--green-light); color:var(--green-dark);">✅</div>
    <strong><?= $stats['approved'] ?></strong>
    <span>Live Listings</span>
    <a href="<?= BASE_URL ?>/admin/products.php?status=approved" class="stat-link">View all &rarr;</a>
  </div>
  <div class="admin-stat-card">
    <div class="icon" style="background:#FDECEC; color:#B42323;">🚫</div>
    <strong><?= $stats['rejected'] ?></strong>
    <span>Rejected</span>
    <a href="<?= BASE_URL ?>/admin/products.php?status=rejected" class="stat-link">View all &rarr;</a>
  </div>
  <div class="admin-stat-card">
    <div class="icon" style="background:var(--blue-light); color:var(--blue-dark);">👥</div>
    <strong><?= $stats['users'] ?></strong>
    <span>Registered Users</span>
    <a href="<?= BASE_URL ?>/admin/users.php" class="stat-link">View all &rarr;</a>
  </div>
</div>

<div class="admin-section-head">
  <h2>⏳ Needs Your Review</h2>
  <a href="<?= BASE_URL ?>/admin/products.php?status=pending" class="btn btn-outline btn-sm">Review All Pending</a>
</div>
<p class="muted" style="margin-top:-10px; margin-bottom:16px; font-size:0.85rem;">Listings now go live immediately when posted — this list only shows anything manually moved back to pending.</p>

<?php if (empty($recentPending)): ?>
  <div class="admin-table-wrap" style="padding:30px; text-align:center; color:var(--gray-500);">
    Nothing waiting for review right now. 🎉
  </div>
<?php else: ?>
  <div class="admin-table-wrap" style="margin-bottom:30px;">
    <table class="admin-table">
      <thead>
        <tr><th>Product</th><th>Category</th><th>Seller</th><th>Listed</th><th>Type</th></tr>
      </thead>
      <tbody>
        <?php foreach ($recentPending as $p): ?>
          <tr>
            <td><strong><?= htmlspecialchars($p['title']) ?></strong></td>
            <td class="muted"><?= htmlspecialchars($p['category_name']) ?> &raquo; <?= htmlspecialchars($p['subcategory_name']) ?></td>
            <td class="muted"><?= htmlspecialchars($p['city']) ?></td>
            <td class="muted"><?= timeAgo($p['created_at']) ?></td>
            <td><span class="status-pill <?= $p['listing_type'] === 'donate' ? 'status-approved' : 'status-sold' ?>"><?= $p['listing_type'] === 'donate' ? 'Donate' : 'Sell' ?></span></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<div class="admin-section-head">
  <h2>👥 Newest Members</h2>
  <a href="<?= BASE_URL ?>/admin/users.php" class="btn btn-outline btn-sm">View All Users</a>
</div>

<?php if (empty($recentUsers)): ?>
  <div class="admin-table-wrap" style="padding:30px; text-align:center; color:var(--gray-500);">
    No one has registered yet.
  </div>
<?php else: ?>
  <div class="admin-table-wrap">
    <table class="admin-table">
      <thead>
        <tr><th>Name</th><th>Email</th><th>Joined</th></tr>
      </thead>
      <tbody>
        <?php foreach ($recentUsers as $u): ?>
          <tr>
            <td><strong><?= htmlspecialchars($u['name']) ?></strong></td>
            <td class="muted"><?= htmlspecialchars($u['email']) ?></td>
            <td class="muted"><?= timeAgo($u['created_at']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
