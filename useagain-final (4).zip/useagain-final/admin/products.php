<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/image-upload.php';
requireAdminLogin();

$admin = currentAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        header('Location: ' . BASE_URL . '/admin/products.php');
        exit;
    }

    $productId = (int) ($_POST['product_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($productId > 0) {
        if ($action === 'approve') {
            approveProduct($productId, $admin['id']);
        } elseif ($action === 'reject') {
            rejectProduct($productId, trim($_POST['rejection_reason'] ?? '') ?: 'Does not meet listing guidelines.');
        } elseif ($action === 'delete') {
            deleteProductCompletely($productId);
        } elseif ($action === 'toggle_featured') {
            toggleFeaturedProduct($productId);
        } elseif ($action === 'hide') {
            hideProduct($productId);
        } elseif ($action === 'restore') {
            restoreProduct($productId);
        } elseif ($action === 'toggle_sold_out') {
            toggleSoldOut($productId);
        }
    }

    header('Location: ' . BASE_URL . '/admin/products.php' . (!empty($_GET['status']) ? '?status=' . urlencode($_GET['status']) : ''));
    exit;
}

$status = trim($_GET['status'] ?? '');
$validStatuses = ['pending', 'approved', 'rejected', 'sold', 'removed'];
if (!in_array($status, $validStatuses, true)) $status = '';

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 20;
$result = getProductsForAdmin($status ?: null, $page, $perPage);
$products = $result['products'];
$totalPages = max(1, (int) ceil($result['total'] / $perPage));

$pageTitle = 'Products';
require_once __DIR__ . '/includes/admin-header.php';
?>

<div class="admin-section-head">
  <div style="display:flex; gap:8px; flex-wrap:wrap;">
    <a href="<?= BASE_URL ?>/admin/products.php" class="btn btn-sm <?= $status === '' ? 'btn-primary' : 'btn-outline' ?>">All</a>
    <?php foreach ($validStatuses as $s): ?>
      <a href="<?= BASE_URL ?>/admin/products.php?status=<?= $s ?>" class="btn btn-sm <?= $status === $s ? 'btn-primary' : 'btn-outline' ?>"><?= ucfirst($s) ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="admin-table-wrap">
  <table class="admin-table">
    <thead><tr><th>Product</th><th>Category</th><th>Seller</th><th>Type</th><th>Price</th><th>Status</th><th>Posted</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($products as $p): ?>
        <tr>
          <td><strong><?= htmlspecialchars($p['title']) ?></strong></td>
          <td class="muted"><?= htmlspecialchars($p['category_name']) ?> &raquo; <?= htmlspecialchars($p['subcategory_name']) ?></td>
          <td class="muted"><?= htmlspecialchars($p['city']) ?></td>
          <td><?= $p['listing_type'] === 'donate' ? 'Donate' : 'Sell' ?></td>
          <td><?= $p['listing_type'] === 'donate' ? '—' : htmlspecialchars(formatPrice($p['price']) ?? '—') ?></td>
          <td><span class="status-pill status-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
          <td class="muted"><?= timeAgo($p['created_at']) ?></td>
          <td class="admin-row-actions">
            <?php if ($p['status'] === 'pending'): ?>
              <form method="post" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                <input type="hidden" name="action" value="approve">
                <button type="submit" class="btn btn-sm btn-primary">Approve</button>
              </form>
              <button type="button" class="btn btn-sm btn-outline" onclick="document.getElementById('rejectForm<?= $p['id'] ?>').classList.toggle('open')">Reject</button>
            <?php endif; ?>
            <a href="<?= BASE_URL ?>/product-details.php?slug=<?= urlencode($p['slug']) ?>" target="_blank" class="btn btn-sm btn-outline">View</a>
            <a href="<?= BASE_URL ?>/admin/edit-product.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline">Edit</a>
            <a href="<?= BASE_URL ?>/admin/product-images.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline">🖼️ Images</a>

            <?php if (in_array($p['status'], ['approved', 'removed'], true)): ?>
              <form method="post" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                <input type="hidden" name="action" value="toggle_sold_out">
                <button type="submit" class="btn btn-sm <?= $p['sold_out'] ? 'btn-primary' : 'btn-outline' ?>"><?= $p['sold_out'] ? '🔴 Sold Out' : 'Mark Sold Out' ?></button>
              </form>
            <?php endif; ?>

            <?php if ($p['status'] === 'approved'): ?>
              <form method="post" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                <input type="hidden" name="action" value="toggle_featured">
                <button type="submit" class="btn btn-sm <?= $p['is_featured'] ? 'btn-primary' : 'btn-outline' ?>"><?= $p['is_featured'] ? '★ Featured' : '☆ Feature' ?></button>
              </form>
              <form method="post" style="display:inline;" onsubmit="return confirm('Hide this listing from the public site? It stays saved and can be restored anytime.');">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                <input type="hidden" name="action" value="hide">
                <button type="submit" class="btn btn-sm btn-outline">Hide</button>
              </form>
            <?php elseif ($p['status'] === 'removed'): ?>
              <form method="post" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                <input type="hidden" name="action" value="restore">
                <button type="submit" class="btn btn-sm btn-primary">Restore / Approve</button>
              </form>
            <?php endif; ?>
            <form method="post" style="display:inline;" onsubmit="return confirm('Permanently delete this listing?');">
              <?= csrf_field() ?>
              <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
              <input type="hidden" name="action" value="delete">
              <button type="submit" class="btn btn-sm btn-outline" style="color:#B42323; border-color:#B42323;">Delete</button>
            </form>

            <?php if ($p['status'] === 'pending'): ?>
              <form method="post" id="rejectForm<?= $p['id'] ?>" class="reject-inline-form">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                <input type="hidden" name="action" value="reject">
                <input type="text" name="rejection_reason" placeholder="Reason for rejection">
                <button type="submit" class="btn btn-sm btn-primary">Confirm Reject</button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($products)): ?>
        <tr><td colspan="8" style="text-align:center; padding:30px; color:var(--gray-500);">No products found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php if ($totalPages > 1): ?>
  <div class="pagination">
    <?php if ($page > 1): ?><a href="?status=<?= $status ?>&page=<?= $page - 1 ?>" class="btn btn-outline btn-sm">&larr; Prev</a><?php endif; ?>
    <span class="small-muted">Page <?= $page ?> of <?= $totalPages ?></span>
    <?php if ($page < $totalPages): ?><a href="?status=<?= $status ?>&page=<?= $page + 1 ?>" class="btn btn-outline btn-sm">Next &rarr;</a><?php endif; ?>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/admin-footer.php'; ?>
