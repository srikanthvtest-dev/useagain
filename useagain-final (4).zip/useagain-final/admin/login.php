<?php
require_once __DIR__ . '/../includes/functions.php';

if (isAdminLoggedIn() && currentAdmin()) {
    header('Location: ' . BASE_URL . '/admin/dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired — please try again.';
    } elseif (isRateLimited('admin_login')) {
        $error = 'Please wait a few seconds before trying again.';
    } else {
        $admin = findAdminByEmail($email);
        if (!$admin || !password_verify($password, $admin['password_hash'])) {
            $error = 'Incorrect email or password.';
        } elseif (!$admin['is_active']) {
            $error = 'This admin account has been deactivated.';
        } else {
            logAdminIn($admin['id']);
            touchAdminLastLogin($admin['id']);
            header('Location: ' . BASE_URL . '/admin/dashboard.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login - UseAgain</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="<?= BASE_URL ?>/assets/images/favicon.svg" type="image/svg+xml">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<style>
  body { background: linear-gradient(120deg, var(--header-dark), var(--header-dark-2)); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
  .admin-login-logo { text-align: center; margin-bottom: 24px; color: #fff; font-size: 1.5rem; font-weight: 800; }
  .admin-login-logo .logo-accent { color: #7FD99A; }
</style>
</head>
<body>
<div>
  <div class="admin-login-logo">♻️ Use<span class="logo-accent">Again</span> <span style="font-weight:500; font-size:0.9rem; opacity:0.8;">Admin</span></div>
  <?php if ($error): ?><div class="alert alert-error" style="max-width:380px; margin:0 auto 16px;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form class="form-card" method="post" action="<?= BASE_URL ?>/admin/login.php" style="width:380px;">
    <?= csrf_field() ?>
    <div class="form-group">
      <label for="email">Admin Email</label>
      <input type="email" id="email" name="email" required autofocus>
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>
    </div>
    <button type="submit" class="btn btn-primary btn-block">Login</button>
  </form>
</div>
</body>
</html>
